# 🏪 Gestion Commerciale Multi-Boutiques

Application web complète de gestion commerciale pour une entreprise opérant plusieurs boutiques. Développée avec Node.js, Express, SQLite et Handlebars.

## 📋 Fonctionnalités

### ✅ Gestion des Boutiques
- Création, modification et suppression de boutiques
- Affichage de la liste complète des boutiques
- Informations détaillées (nom, téléphone, adresse)

### 📦 Gestion des Produits
- CRUD complet des produits
- Organisation par catégories
- Code produit unique
- Prix unitaire

### 📊 Gestion des Stocks
- Suivi du stock par boutique et par produit
- Ajout d'approvisionnement
- Alertes de stock faible
- Historique des mouvements

### 💰 Gestion des Ventes
- Enregistrement des ventes
- Sélection dynamique des vendeurs par boutique
- Vérification automatique du stock disponible
- Prévisualisation du montant total
- Déduction automatique du stock

### 📈 Tableau de Bord
- Statistiques des ventes du jour
- Alertes de stock critique
- Top produits vendus (7 derniers jours)
- Actions rapides

## 🚀 Installation

### Prérequis
- Node.js >= 14.x
- npm >= 6.x

### Étapes d'installation

1. **Créer le répertoire du projet**
```bash
mkdir gestion-commerciale
cd gestion-commerciale
```

2. **Initialiser npm et installer les dépendances**
```bash
npm init -y
npm install express express-handlebars sqlite3 body-parser dotenv express-validator morgan
npm install --save-dev nodemon
```

3. **Créer la structure des dossiers**
```bash
mkdir -p src/{config,models,controllers,routes,middlewares,views/{layouts,partials,boutiques,produits,stocks,ventes},public/{css,js},utils}
```

4. **Copier tous les fichiers fournis** dans leurs dossiers respectifs selon l'arborescence :

```
gestion-commerciale/
├── src/
│   ├── config/
│   │   └── database.js
│   ├── models/
│   │   ├── boutique.js
│   │   ├── produit.js
│   │   ├── categorie.js
│   │   ├── agent.js
│   │   ├── approvisionnement.js
│   │   └── vente.js
│   ├── controllers/
│   │   ├── boutiqueController.js
│   │   ├── produitController.js
│   │   ├── stockController.js
│   │   └── venteController.js
│   ├── routes/
│   │   ├── boutiques.js
│   │   ├── produits.js
│   │   ├── stocks.js
│   │   └── ventes.js
│   ├── middlewares/
│   │   ├── errorHandler.js
│   │   └── validator.js
│   ├── views/
│   │   ├── layouts/
│   │   │   └── main.hbs
│   │   ├── partials/
│   │   │   ├── header.hbs
│   │   │   ├── footer.hbs
│   │   │   └── alerts.hbs
│   │   ├── dashboard.hbs
│   │   ├── error.hbs
│   │   ├── boutiques/
│   │   │   ├── list.hbs
│   │   │   └── form.hbs
│   │   ├── produits/
│   │   │   ├── list.hbs
│   │   │   └── form.hbs
│   │   ├── stocks/
│   │   │   ├── list.hbs
│   │   │   └── form.hbs
│   │   └── ventes/
│   │       ├── list.hbs
│   │       └── form.hbs
│   ├── public/
│   │   ├── css/
│   │   │   └── style.css
│   │   └── js/
│   │       └── main.js
│   ├── utils/
│   │   ├── helpers.js
│   │   └── logger.js
│   └── app.js
├── package.json
├── .env
└── README.md
```

5. **Créer le fichier .env** à la racine du projet
```env
PORT=3000
DB_PATH=./database.sqlite
NODE_ENV=development
```

6. **Modifier le package.json** pour ajouter les scripts
```json
{
  "scripts": {
    "start": "node src/app.js",
    "dev": "nodemon src/app.js"
  }
}
```

## 🎯 Démarrage

### Mode développement (avec rechargement automatique)
```bash
npm run dev
```

### Mode production
```bash
npm start
```

L'application sera accessible sur : **http://localhost:3000**

## 📱 Utilisation

### Accès à l'application
1. Ouvrez votre navigateur
2. Accédez à `http://localhost:3000`
3. Vous serez redirigé automatiquement vers le tableau de bord

### Navigation
- **Dashboard** : Vue d'ensemble des statistiques
- **Boutiques** : Gestion des boutiques
- **Produits** : Catalogue des produits
- **Stocks** : Gestion des approvisionnements
- **Ventes** : Enregistrement et historique des ventes

### Workflow typique

#### 1. Créer une boutique
```
Dashboard → Boutiques → Nouvelle Boutique
```
Remplir : nom, téléphone, adresse

#### 2. Ajouter des produits
```
Dashboard → Produits → Nouveau Produit
```
Remplir : nom, code, prix, catégorie

#### 3. Approvisionner le stock
```
Dashboard → Stocks → Ajouter du Stock
```
Sélectionner : produit, boutique, quantité

#### 4. Enregistrer une vente
```
Dashboard → Ventes → Nouvelle Vente
```
Processus :
1. Sélectionner la boutique
2. Choisir le vendeur (liste dynamique)
3. Sélectionner le produit
4. Entrer la quantité
5. Voir la prévisualisation du total
6. Enregistrer

## 🔍 Architecture

### Couches de l'application

#### 1. Couche de données (Models)
- Interaction avec SQLite
- Promesses pour l'asynchronisme
- Méthodes CRUD

#### 2. Couche métier (Controllers)
- Logique applicative
- Validation des données
- Gestion des erreurs métier

#### 3. Couche de présentation (Views)
- Templates Handlebars
- Helpers personnalisés
- Responsive design

#### 4. Couche de routage (Routes)
- Routes web (HTML)
- Routes API (JSON)
- Middleware de validation

### Base de données

#### Tables principales
- **BOUTIQUE** : Informations des boutiques
- **PRODUIT** : Catalogue des produits
- **CATEGORIE** : Catégories de produits
- **AGENT_VENDEUR** : Employés vendeurs
- **SUPERVISEUR** : Superviseurs
- **APPROVIONNEMENT** : Stocks par boutique
- **VENTE** : Transactions de vente
- **UTILISATEUR** : Utilisateurs du système
- **SUIVI** : Périodes de suivi des agents
- **SUPERVISER** : Affectations des superviseurs

#### Contraintes
- Clés étrangères activées
- Contraintes d'unicité (codes produits, emails)
- Validation des stocks (pas de valeurs négatives)
- Cascade pour les suppressions

## 🛡️ Validation et Sécurité

### Validation côté serveur
- Express-validator pour toutes les entrées
- Vérification des formats (téléphone, email, codes)
- Validation des plages de valeurs
- Protection contre les injections SQL (requêtes paramétrées)

### Validation côté client
- Validation HTML5 native
- JavaScript pour validation dynamique
- Messages d'erreur contextuels
- Prévention des soumissions invalides

### Gestion des erreurs
- Middleware centralisé
- Codes HTTP appropriés (400, 404, 409, 500)
- Messages utilisateur clairs
- Logging détaillé pour le débogage

## 📊 API Endpoints

### Boutiques
```
GET    /boutiques              - Liste des boutiques (HTML)
GET    /boutiques/new          - Formulaire création
GET    /boutiques/edit/:id     - Formulaire édition
POST   /boutiques/create       - Créer une boutique
POST   /boutiques/update/:id   - Modifier une boutique
POST   /boutiques/delete/:id   - Supprimer une boutique
GET    /boutiques/api/all      - Liste des boutiques (JSON)
GET    /boutiques/api/:id      - Détails d'une boutique (JSON)
```

### Produits
```
GET    /produits               - Liste des produits (HTML)
GET    /produits/new           - Formulaire création
GET    /produits/edit/:id      - Formulaire édition
POST   /produits/create        - Créer un produit
POST   /produits/update/:id    - Modifier un produit
POST   /produits/delete/:id    - Supprimer un produit
GET    /produits/api/all       - Liste des produits (JSON)
```

### Stocks
```
GET    /stocks                 - Liste des stocks (HTML)
GET    /stocks/new             - Formulaire ajout
POST   /stocks/add             - Ajouter du stock
GET    /stocks/api/check       - Vérifier stock disponible (JSON)
```

### Ventes
```
GET    /ventes                      - Historique des ventes (HTML)
GET    /ventes/new                  - Formulaire vente
POST   /ventes/create               - Enregistrer une vente
GET    /ventes/api/agents/:boutiqueId - Agents d'une boutique (JSON)
```

## 🎨 Personnalisation

### Modifier les couleurs
Éditer `src/public/css/style.css` et modifier les variables CSS :
```css
:root {
    --primary-color: #2563eb;
    --secondary-color: #64748b;
    --success-color: #10b981;
    --danger-color: #ef4444;
    --warning-color: #f59e0b;
    --info-color: #06b6d4;
}
```

### Ajouter de nouvelles catégories
Insérer directement dans la base de données :
```sql
INSERT INTO CATEGORIE (nom_categorie) VALUES ('Nouvelle Catégorie');
```

### Personnaliser les helpers Handlebars
Éditer `src/utils/helpers.js` pour ajouter de nouveaux helpers.

## 🐛 Dépannage

### Port déjà utilisé
```bash
# Changer le port dans .env
PORT=3001
```

### Erreurs de base de données
```bash
# Supprimer et recréer la base
rm database.sqlite
npm start
```

### Problèmes de modules
```bash
# Réinstaller les dépendances
rm -rf node_modules
npm install
```

## 📝 Données d'exemple

L'application génère automatiquement des données d'exemple au premier lancement :
- 3 boutiques
- 5 catégories
- 10 produits
- 5 agents vendeurs
- 2 superviseurs
- Stocks initiaux
- Quelques ventes du jour

## 🔄 Améliorations futures possibles

- [ ] Authentification et autorisation
- [ ] Export des rapports en PDF/Excel
- [ ] Graphiques et statistiques avancées
- [ ] Gestion des retours et remboursements
- [ ] Système de notifications
- [ ] API RESTful complète avec documentation Swagger
- [ ] Tests unitaires et d'intégration
- [ ] Déploiement Docker

## 👨‍💻 Développeur

Projet académique - Gestion Commerciale Multi-Boutiques

## 📄 Licence

Projet éducatif - Utilisation libre pour l'apprentissage

---

**Note** : Ce projet utilise SQLite pour la persistance des données. Pour une utilisation en production, il est recommandé de migrer vers PostgreSQL ou MySQL.