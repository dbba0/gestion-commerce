// ============================================
// FICHIER: src/app.js (MISE À JOUR COMPLÈTE)
// ============================================
require('dotenv').config();
const express = require('express');
const { engine } = require('express-handlebars');
const bodyParser = require('body-parser');
const path = require('path');
const morgan = require('morgan');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);

// Import des middlewares
const errorHandler = require('./middlewares/errorHandler');
const { requireAuth, requireRole, attachUser } = require('./middlewares/auth');

// Import des routes
const authRoutes = require('./routes/auth');
const boutiqueRoutes = require('./routes/boutiques');
const produitRoutes = require('./routes/produits');
const stockRoutes = require('./routes/stocks');
const venteRoutes = require('./routes/ventes');
const superviseurRoutes = require('./routes/superviseurs');
const agentRoutes = require('./routes/agents');
const rapportRoutes = require('./routes/rapports');

// Import des helpers
const helpers = require('./utils/helpers');

// Import de la base de données
const { initDatabase } = require('./config/database');

const app = express();
const PORT = process.env.PORT || 3000;

// Configuration des sessions
app.use(session({
  store: new SQLiteStore({
    db: 'sessions.sqlite',
    dir: './'
  }),
  secret: process.env.SESSION_SECRET || 'votre-secret-super-securise-changez-moi',
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 24 * 60 * 60 * 1000, // 24 heures
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production' // HTTPS en production
  }
}));

// Configuration Handlebars
app.engine('hbs', engine({
  extname: '.hbs',
  defaultLayout: 'main',
  layoutsDir: path.join(__dirname, 'views/layouts'),
  partialsDir: path.join(__dirname, 'views/partials'),
  helpers: helpers
}));
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'views'));

// Middlewares
app.use(morgan('dev'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Middleware pour attacher l'utilisateur à toutes les requêtes
app.use(attachUser);

// Routes publiques (pas d'authentification requise)
app.use('/auth', authRoutes);

// Page d'accueil (redirection)
app.get('/', async (req, res) => {
  if (req.session && req.session.userId) {
    res.redirect('/dashboard');
  } else {
    res.redirect('/auth/login');
  }
});

// Routes protégées (authentification requise)
app.get('/dashboard', requireAuth, async (req, res, next) => {
  try {
    const db = require('./config/database').getDatabase();
    
    // Récupérer les statistiques du jour
    const today = new Date().toISOString().split('T')[0];
    
    const ventesJour = await new Promise((resolve, reject) => {
      db.get(
        `SELECT COUNT(*) as total, SUM(qte_vendue) as quantite, SUM(montant_total) as recettes
         FROM VENTE
         WHERE date(date_vente) = date(?)`,
        [today],
        (err, row) => err ? reject(err) : resolve(row)
      );
    });

    const alertesStock = await new Promise((resolve, reject) => {
      db.all(
        `SELECT p.nom_produit, b.nom_boutique, a.quantite_stock 
         FROM APPROVIONNEMENT a
         INNER JOIN PRODUIT p ON a.produit_id = p.produit_id
         INNER JOIN BOUTIQUE b ON a.boutique_id = b.boutique_id
         WHERE a.quantite_stock < 10
         ORDER BY a.quantite_stock ASC
         LIMIT 10`,
        [],
        (err, rows) => err ? reject(err) : resolve(rows)
      );
    });

    const produitsPopulaires = await new Promise((resolve, reject) => {
      db.all(
        `SELECT p.nom_produit, SUM(v.qte_vendue) as total_vendu
         FROM VENTE v
         INNER JOIN PRODUIT p ON v.produit_id = p.produit_id
         WHERE date(v.date_vente) >= date('now', '-7 days')
         GROUP BY p.produit_id, p.nom_produit
         ORDER BY total_vendu DESC
         LIMIT 5`,
        [],
        (err, rows) => err ? reject(err) : resolve(rows)
      );
    });

    res.render('dashboard', {
      title: 'Tableau de Bord',
      ventesJour,
      alertesStock,
      produitsPopulaires
    });
  } catch (error) {
    next(error);
  }
});

// Routes protégées avec authentification
app.use('/boutiques', requireAuth, boutiqueRoutes);
app.use('/produits', requireAuth, produitRoutes);
app.use('/stocks', requireAuth, stockRoutes);
app.use('/ventes', requireAuth, venteRoutes);
app.use('/agents', requireAuth, agentRoutes);

// Routes avec restriction par rôle (admin/superviseur uniquement)
app.use('/superviseurs', requireAuth, requireRole('admin', 'superviseur'), superviseurRoutes);
app.use('/rapports', requireAuth, requireRole('admin', 'superviseur'), rapportRoutes);

// Middleware de gestion d'erreurs (doit être en dernier)
app.use(errorHandler);

// Initialisation de la base de données et démarrage du serveur
initDatabase()
  .then(() => {
    const server = app.listen(PORT, () => {
      console.log(`🚀 Serveur démarré sur http://localhost:${PORT}`);
      console.log(`🔐 Page de connexion: http://localhost:${PORT}/auth/login`);
      console.log(`📊 Dashboard disponible sur http://localhost:${PORT}/dashboard`);
    });

    // Configuration Socket.IO (pour la partie temps réel - étape suivante)
    const io = require('socket.io')(server);
    app.set('io', io);

    io.on('connection', (socket) => {
      console.log('👤 Nouvelle connexion WebSocket');
      
      socket.on('disconnect', () => {
        console.log('👋 Déconnexion WebSocket');
      });
    });
  })
  .catch(err => {
    console.error('❌ Erreur lors de l\'initialisation de la base de données:', err);
    process.exit(1);
  });