// ============================================
// FICHIER: src/controllers/authController.js 
// ============================================

const Utilisateur = require('../models/utilisateur');
const { validationResult } = require('express-validator');

// Afficher la page de connexion
exports.showLoginForm = (req, res) => {
  if (req.session && req.session.userId) {
    return res.redirect('/dashboard');
  }
  
  res.render('auth/login', {
    title: 'Connexion',
    error: req.query.error,
    layout: 'auth' // Layout spécial sans navigation
  });
};

// Afficher la page d'inscription
exports.showRegisterForm = (req, res) => {
  if (req.session && req.session.userId) {
    return res.redirect('/dashboard');
  }
  
  res.render('auth/register', {
    title: 'Inscription',
    layout: 'auth'
  });
};

// Traiter la connexion
exports.login = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).render('auth/login', {
        title: 'Connexion',
        layout: 'auth',
        errors: errors.array(),
        formData: req.body
      });
    }

    const { username, password } = req.body;
    const user = await Utilisateur.authenticate(username, password);

    if (!user) {
      return res.status(401).render('auth/login', {
        title: 'Connexion',
        layout: 'auth',
        errors: [{ msg: 'Nom d\'utilisateur ou mot de passe incorrect' }],
        formData: req.body
      });
    }

    // Créer la session
    req.session.userId = user.utilisateur_id;
    req.session.userName = user.user_name;
    req.session.userRole = user.user_role;

    // Logger la connexion
    console.log(`✅ Connexion réussie: ${user.user_name} (${user.user_role})`);

    res.redirect('/dashboard');
  } catch (error) {
    next(error);
  }
};

// Traiter l'inscription
exports.register = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).render('auth/register', {
        title: 'Inscription',
        layout: 'auth',
        errors: errors.array(),
        formData: req.body
      });
    }

    const { username, email, password, role } = req.body;

    // Vérifier si l'utilisateur existe déjà
    const existingUser = await Utilisateur.getByUsername(username);
    if (existingUser) {
      return res.status(409).render('auth/register', {
        title: 'Inscription',
        layout: 'auth',
        errors: [{ msg: 'Ce nom d\'utilisateur est déjà utilisé' }],
        formData: req.body
      });
    }

    const existingEmail = await Utilisateur.getByEmail(email);
    if (existingEmail) {
      return res.status(409).render('auth/register', {
        title: 'Inscription',
        layout: 'auth',
        errors: [{ msg: 'Cet email est déjà utilisé' }],
        formData: req.body
      });
    }

    // Créer l'utilisateur
    const user = await Utilisateur.create({
      user_name: username,
      user_password: password,
      user_email: email,
      user_role: role || 'agent'
    });

    console.log(`✅ Nouvel utilisateur créé: ${user.user_name} (${user.user_role})`);

    // Connecter automatiquement l'utilisateur
    req.session.userId = user.utilisateur_id;
    req.session.userName = user.user_name;
    req.session.userRole = user.user_role;

    res.redirect('/dashboard');
  } catch (error) {
    next(error);
  }
};

// Déconnexion
exports.logout = (req, res) => {
  const userName = req.session?.userName;
  
  req.session.destroy((err) => {
    if (err) {
      console.error('Erreur lors de la déconnexion:', err);
    }
    
    console.log(`👋 Déconnexion: ${userName}`);
    res.redirect('/auth/login?success=logout');
  });
};

// API: Vérifier l'état de connexion
exports.checkAuth = (req, res) => {
  if (req.session && req.session.userId) {
    res.json({
      authenticated: true,
      user: {
        id: req.session.userId,
        name: req.session.userName,
        role: req.session.userRole
      }
    });
  } else {
    res.json({ authenticated: false });
  }
};