// ============================================
// FICHIER: src/controllers/boutiqueController.js
// ============================================

const Boutique = require('../models/boutique');
const { validationResult } = require('express-validator');

exports.listBoutiques = async (req, res, next) => {
  try {
    const boutiques = await Boutique.getAll();
    res.render('boutiques/list', {
      title: 'Gestion des Boutiques',
      boutiques,
      success: req.query.success
    });
  } catch (error) {
    next(error);
  }
};

exports.showFormCreate = (req, res) => {
  res.render('boutiques/form', {
    title: 'Nouvelle Boutique',
    boutique: {},
    action: '/boutiques/create'
  });
};

exports.showFormEdit = async (req, res, next) => {
  try {
    const boutique = await Boutique.getById(req.params.id);
    if (!boutique) {
      return res.status(404).render('error', { 
        message: 'Boutique non trouvée',
        error: { status: 404 }
      });
    }
    res.render('boutiques/form', {
      title: 'Modifier Boutique',
      boutique,
      action: `/boutiques/update/${boutique.boutique_id}`
    });
  } catch (error) {
    next(error);
  }
};

exports.createBoutique = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).render('boutiques/form', {
        title: 'Nouvelle Boutique',
        boutique: req.body,
        action: '/boutiques/create',
        errors: errors.array()
      });
    }

    await Boutique.create(req.body);
    res.redirect('/boutiques?success=created');
  } catch (error) {
    next(error);
  }
};

exports.updateBoutique = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).render('boutiques/form', {
        title: 'Modifier Boutique',
        boutique: { boutique_id: req.params.id, ...req.body },
        action: `/boutiques/update/${req.params.id}`,
        errors: errors.array()
      });
    }

    await Boutique.update(req.params.id, req.body);
    res.redirect('/boutiques?success=updated');
  } catch (error) {
    next(error);
  }
};

exports.deleteBoutique = async (req, res, next) => {
  try {
    await Boutique.delete(req.params.id);
    res.redirect('/boutiques?success=deleted');
  } catch (error) {
    if (error.message.includes('FOREIGN KEY')) {
      return res.status(409).render('error', {
        message: 'Impossible de supprimer cette boutique car elle contient des données',
        error: { status: 409 }
      });
    }
    next(error);
  }
};

// API endpoints
exports.getAllBoutiquesAPI = async (req, res, next) => {
  try {
    const boutiques = await Boutique.getAll();
    res.json({ success: true, data: boutiques });
  } catch (error) {
    next(error);
  }
};

exports.getBoutiqueAPI = async (req, res, next) => {
  try {
    const boutique = await Boutique.getById(req.params.id);
    if (!boutique) {
      return res.status(404).json({ success: false, message: 'Boutique non trouvée' });
    }
    res.json({ success: true, data: boutique });
  } catch (error) {
    next(error);
  }
};

exports.createBoutiqueAPI = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const boutique = await Boutique.create(req.body);
    res.status(201).json({ success: true, data: boutique });
  } catch (error) {
    next(error);
  }
};