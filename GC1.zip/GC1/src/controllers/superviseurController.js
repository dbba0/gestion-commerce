// ============================================
// FICHIER: src/controllers/superviseurController.js
// ============================================

const Superviseur = require('../models/superviseur');
const { validationResult } = require('express-validator');

exports.listSuperviseurs = async (req, res, next) => {
  try {
    const superviseurs = await Superviseur.getAll();
    res.render('superviseurs/list', {
      title: 'Gestion des Superviseurs',
      superviseurs,
      success: req.query.success
    });
  } catch (error) {
    next(error);
  }
};

exports.showFormCreate = (req, res) => {
  res.render('superviseurs/form', {
    title: 'Nouveau Superviseur',
    superviseur: {},
    action: '/superviseurs/create'
  });
};

exports.showFormEdit = async (req, res, next) => {
  try {
    const superviseur = await Superviseur.getById(req.params.id);
    if (!superviseur) {
      return res.status(404).render('error', { 
        message: 'Superviseur non trouvé',
        error: { status: 404 }
      });
    }
    res.render('superviseurs/form', {
      title: 'Modifier Superviseur',
      superviseur,
      action: `/superviseurs/update/${superviseur.supervis_id}`
    });
  } catch (error) {
    next(error);
  }
};

exports.createSuperviseur = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).render('superviseurs/form', {
        title: 'Nouveau Superviseur',
        superviseur: req.body,
        action: '/superviseurs/create',
        errors: errors.array()
      });
    }

    await Superviseur.create(req.body);
    res.redirect('/superviseurs?success=created');
  } catch (error) {
    next(error);
  }
};

exports.updateSuperviseur = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).render('superviseurs/form', {
        title: 'Modifier Superviseur',
        superviseur: { supervis_id: req.params.id, ...req.body },
        action: `/superviseurs/update/${req.params.id}`,
        errors: errors.array()
      });
    }

    await Superviseur.update(req.params.id, req.body);
    res.redirect('/superviseurs?success=updated');
  } catch (error) {
    next(error);
  }
};

exports.deleteSuperviseur = async (req, res, next) => {
  try {
    await Superviseur.delete(req.params.id);
    res.redirect('/superviseurs?success=deleted');
  } catch (error) {
    next(error);
  }
};

exports.viewBoutiques = async (req, res, next) => {
  try {
    const superviseur = await Superviseur.getById(req.params.id);
    const boutiques = await Superviseur.getBoutiquesSupervisees(req.params.id);
    
    res.render('superviseurs/boutiques', {
      title: `Boutiques supervisées - ${superviseur.prenom_supervis} ${superviseur.nom_superviss}`,
      superviseur,
      boutiques
    });
  } catch (error) {
    next(error);
  }
};

// Afficher le formulaire d'affectation
exports.showFormAffectation = async (req, res, next) => {
  try {
    const Boutique = require('../models/boutique');
    const superviseur = await Superviseur.getById(req.params.id);
    const boutiques = await Boutique.getAll();
    
    if (!superviseur) {
      return res.status(404).render('error', { 
        message: 'Superviseur non trouvé',
        error: { status: 404 }
      });
    }

    res.render('superviseurs/affecter', {
      title: `Affecter ${superviseur.prenom_supervis} ${superviseur.nom_superviss} à une boutique`,
      superviseur,
      boutiques
    });
  } catch (error) {
    next(error);
  }
};

// Affecter un superviseur à une boutique
exports.affecterBoutique = async (req, res, next) => {
  try {
    const { validationResult } = require('express-validator');
    const errors = validationResult(req);
    
    if (!errors.isEmpty()) {
      const Boutique = require('../models/boutique');
      const superviseur = await Superviseur.getById(req.params.id);
      const boutiques = await Boutique.getAll();
      
      return res.status(400).render('superviseurs/affecter', {
        title: `Affecter ${superviseur.prenom_supervis} ${superviseur.nom_superviss} à une boutique`,
        superviseur,
        boutiques,
        affectation: req.body,
        errors: errors.array()
      });
    }

    const { boutique_id, debut_supervis, fin_supervis } = req.body;
    
    await Superviseur.assignerBoutique(
      req.params.id,
      boutique_id,
      debut_supervis,
      fin_supervis || null
    );

    res.redirect(`/superviseurs/${req.params.id}/boutiques?success=assigned`);
  } catch (error) {
    next(error);
  }
};

// Terminer une supervision
exports.terminerSupervision = async (req, res, next) => {
  try {
    const { date_fin } = req.body;
    const dateFin = date_fin || new Date().toISOString().split('T')[0];
    
    await Superviseur.terminerSupervision(req.params.id, dateFin);
    
    // Rediriger vers la page des boutiques du superviseur
    const db = require('../config/database').getDatabase();
    const supervision = await new Promise((resolve, reject) => {
      db.get(
        'SELECT supervis_id FROM SUPERVISER WHERE superviser_id = ?',
        [req.params.id],
        (err, row) => err ? reject(err) : resolve(row)
      );
    });
    
    if (supervision) {
      res.redirect(`/superviseurs/${supervision.supervis_id}/boutiques?success=ended`);
    } else {
      res.redirect('/superviseurs?success=ended');
    }
  } catch (error) {
    next(error);
  }
};