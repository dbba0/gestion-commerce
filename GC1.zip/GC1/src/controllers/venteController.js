// ============================================
// FICHIER: src/controllers/venteController.js
// ============================================

const Vente = require('../models/vente');
const Produit = require('../models/produit');
const Boutique = require('../models/boutique');
const Agent = require('../models/agent');
const Approvisionnement = require('../models/approvisionnement');
const { validationResult } = require('express-validator');

exports.listVentes = async (req, res, next) => {
  try {
    const ventes = await Vente.getAll(100);
    res.render('ventes/list', {
      title: 'Historique des Ventes',
      ventes,
      success: req.query.success
    });
  } catch (error) {
    next(error);
  }
};

exports.showFormCreate = async (req, res, next) => {
  try {
    const [produits, boutiques] = await Promise.all([
      Produit.getAll(),
      Boutique.getAll()
    ]);

    res.render('ventes/form', {
      title: 'Nouvelle Vente',
      produits,
      boutiques,
      action: '/ventes/create'
    });
  } catch (error) {
    next(error);
  }
};

exports.createVente = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const [produits, boutiques] = await Promise.all([
        Produit.getAll(),
        Boutique.getAll()
      ]);
      return res.status(400).render('ventes/form', {
        title: 'Nouvelle Vente',
        produits,
        boutiques,
        vente: req.body,
        action: '/ventes/create',
        errors: errors.array()
      });
    }

    const { produit_id, boutique_id, agent_id, qte_vendue } = req.body;

    // Récupérer le produit et la boutique AVANT tout le reste
    const produit = await Produit.getById(produit_id);
    const boutique = await Boutique.getById(boutique_id);

    if (!produit) {
      return res.status(404).render('error', {
        message: 'Produit non trouvé',
        error: { status: 404 }
      });
    }

    if (!boutique) {
      return res.status(404).render('error', {
        message: 'Boutique non trouvée',
        error: { status: 404 }
      });
    }

    // Vérifier le stock disponible
    const stockActuel = await Approvisionnement.getStock(produit_id, boutique_id);
    if (stockActuel < parseInt(qte_vendue)) {
      const [produits, boutiques] = await Promise.all([
        Produit.getAll(),
        Boutique.getAll()
      ]);
      return res.status(409).render('ventes/form', {
        title: 'Nouvelle Vente',
        produits,
        boutiques,
        vente: req.body,
        action: '/ventes/create',
        errors: [{ msg: `Stock insuffisant. Stock disponible: ${stockActuel}` }]
      });
    }

    // Calculer le montant total
    const montant_total = produit.prix_unitaire * parseInt(qte_vendue);

    // Créer la vente
    await Vente.create({
      produit_id: parseInt(produit_id),
      boutique_id: parseInt(boutique_id),
      agent_id: parseInt(agent_id),
      qte_vendue: parseInt(qte_vendue),
      montant_total: montant_total.toFixed(2),
      date_vente: new Date().toISOString()
    });

    // Déduire du stock
    await Approvisionnement.updateStock(produit_id, boutique_id, -parseInt(qte_vendue));

    // Émettre la notification en temps réel (si Socket.IO disponible)
    try {
      const io = req.app.get('io');
      if (io) {
        io.emit('nouvelle_vente', {
          produit: produit.nom_produit,
          quantite: qte_vendue,
          montant: montant_total,
          boutique: boutique.nom_boutique
        });

        // Vérifier si le stock est faible
        const stockRestant = stockActuel - parseInt(qte_vendue);
        if (stockRestant < 10) {
          io.emit('alerte_stock', {
            produit: produit.nom_produit,
            boutique: boutique.nom_boutique,
            quantite: stockRestant,
            niveau: stockRestant === 0 ? 'rupture' : stockRestant < 5 ? 'critique' : 'faible'
          });
        }
      }
    } catch (socketError) {
      console.error('Erreur Socket.IO (non bloquant):', socketError);
    }

    res.redirect('/ventes?success=created');
  } catch (error) {
    next(error);
  }
};

// API endpoint pour obtenir les agents d'une boutique
exports.getAgentsByBoutiqueAPI = async (req, res, next) => {
  try {
    const agents = await Agent.getByBoutique(req.params.boutiqueId);
    res.json({ success: true, data: agents });
  } catch (error) {
    next(error);
  }
};