// ============================================
// FICHIER: src/controllers/stockController.js
// ============================================

const Approvisionnement = require('../models/approvisionnement');
const Produit = require('../models/produit');
const Boutique = require('../models/boutique');
const { validationResult } = require('express-validator');

exports.listStocks = async (req, res, next) => {
  try {
    const stocks = await Approvisionnement.getAll();
    res.render('stocks/list', {
      title: 'Gestion des Stocks',
      stocks,
      success: req.query.success
    });
  } catch (error) {
    next(error);
  }
};

exports.showFormAdd = async (req, res, next) => {
  try {
    const [produits, boutiques] = await Promise.all([
      Produit.getAll(),
      Boutique.getAll()
    ]);

    res.render('stocks/form', {
      title: 'Ajouter du Stock',
      produits,
      boutiques,
      action: '/stocks/add'
    });
  } catch (error) {
    next(error);
  }
};

exports.addStock = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const [produits, boutiques] = await Promise.all([
        Produit.getAll(),
        Boutique.getAll()
      ]);
      return res.status(400).render('stocks/form', {
        title: 'Ajouter du Stock',
        produits,
        boutiques,
        stock: req.body,
        action: '/stocks/add',
        errors: errors.array()
      });
    }

    const { produit_id, boutique_id, quantite } = req.body;
    const date_stock = new Date().toISOString().split('T')[0];

    await Approvisionnement.addStock({
      produit_id: parseInt(produit_id),
      boutique_id: parseInt(boutique_id),
      quantite: parseInt(quantite),
      date_stock
    });

    res.redirect('/stocks?success=added');
  } catch (error) {
    next(error);
  }
};

// API endpoint
exports.getStockAPI = async (req, res, next) => {
  try {
    const { produit_id, boutique_id } = req.query;
    
    if (!produit_id || !boutique_id) {
      return res.status(400).json({ 
        success: false, 
        message: 'produit_id et boutique_id requis' 
      });
    }

    const quantite = await Approvisionnement.getStock(produit_id, boutique_id);
    res.json({ success: true, data: { quantite_stock: quantite } });
  } catch (error) {
    next(error);
  }
};
