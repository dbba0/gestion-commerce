const { getDatabase } = require('../config/database');

exports.showRapports = async (req, res, next) => {
  try {
    const db = getDatabase();

    // Statistiques générales
    const statsGenerales = await new Promise((resolve, reject) => {
      db.get(
        `SELECT 
          (SELECT COUNT(*) FROM BOUTIQUE) as nb_boutiques,
          (SELECT COUNT(*) FROM PRODUIT) as nb_produits,
          (SELECT COUNT(*) FROM AGENT_VENDEUR) as nb_agents,
          (SELECT COUNT(*) FROM VENTE) as nb_ventes_total,
          (SELECT SUM(montant_total) FROM VENTE) as ca_total`,
        [],
        (err, row) => err ? reject(err) : resolve(row)
      );
    });

    // Ventes par boutique
    const ventesParBoutique = await new Promise((resolve, reject) => {
      db.all(
        `SELECT 
          b.nom_boutique,
          COUNT(v.vente_id) as nb_ventes,
          SUM(v.qte_vendue) as qte_totale,
          SUM(v.montant_total) as ca_total,
          AVG(v.montant_total) as panier_moyen
         FROM BOUTIQUE b
         LEFT JOIN VENTE v ON b.boutique_id = v.boutique_id
         GROUP BY b.boutique_id, b.nom_boutique
         ORDER BY ca_total DESC`,
        [],
        (err, rows) => err ? reject(err) : resolve(rows)
      );
    });

    // Performances des agents
    const performancesAgents = await new Promise((resolve, reject) => {
      db.all(
        `SELECT 
          a.prenom_agent || ' ' || a.nom_agent as agent,
          b.nom_boutique,
          COUNT(v.vente_id) as nb_ventes,
          SUM(v.qte_vendue) as qte_vendue,
          SUM(v.montant_total) as ca_total,
          AVG(v.montant_total) as panier_moyen
         FROM AGENT_VENDEUR a
         INNER JOIN BOUTIQUE b ON a.boutique_id = b.boutique_id
         LEFT JOIN VENTE v ON a.agent_id = v.agent_id
         GROUP BY a.agent_id, a.prenom_agent, a.nom_agent, b.nom_boutique
         ORDER BY ca_total DESC
         LIMIT 10`,
        [],
        (err, rows) => err ? reject(err) : resolve(rows)
      );
    });

    // Produits les plus vendus
    const topProduits = await new Promise((resolve, reject) => {
      db.all(
        `SELECT 
          p.nom_produit,
          p.code_produit,
          c.nom_categorie,
          COUNT(v.vente_id) as nb_ventes,
          SUM(v.qte_vendue) as qte_totale,
          SUM(v.montant_total) as ca_total
         FROM PRODUIT p
         INNER JOIN CATEGORIE c ON p.categorie_id = c.categorie_id
         LEFT JOIN VENTE v ON p.produit_id = v.produit_id
         GROUP BY p.produit_id, p.nom_produit, p.code_produit, c.nom_categorie
         HAVING nb_ventes > 0
         ORDER BY qte_totale DESC
         LIMIT 15`,
        [],
        (err, rows) => err ? reject(err) : resolve(rows)
      );
    });

    // Évolution des ventes (7 derniers jours)
    const evolutionVentes = await new Promise((resolve, reject) => {
      db.all(
        `SELECT 
          date(date_vente) as date,
          COUNT(vente_id) as nb_ventes,
          SUM(qte_vendue) as qte_totale,
          SUM(montant_total) as ca_jour
         FROM VENTE
         WHERE date(date_vente) >= date('now', '-7 days')
         GROUP BY date(date_vente)
         ORDER BY date DESC`,
        [],
        (err, rows) => err ? reject(err) : resolve(rows)
      );
    });

    // Stocks critiques par boutique
    const stocksCritiques = await new Promise((resolve, reject) => {
      db.all(
        `SELECT 
          b.nom_boutique,
          p.nom_produit,
          p.code_produit,
          a.quantite_stock,
          CASE 
            WHEN a.quantite_stock = 0 THEN 'Rupture'
            WHEN a.quantite_stock < 5 THEN 'Critique'
            WHEN a.quantite_stock < 10 THEN 'Faible'
          END as niveau_alerte
         FROM APPROVIONNEMENT a
         INNER JOIN PRODUIT p ON a.produit_id = p.produit_id
         INNER JOIN BOUTIQUE b ON a.boutique_id = b.boutique_id
         WHERE a.quantite_stock < 10
         ORDER BY a.quantite_stock ASC, b.nom_boutique`,
        [],
        (err, rows) => err ? reject(err) : resolve(rows)
      );
    });

    res.render('rapports/dashboard', {
      title: 'Rapports et Statistiques',
      statsGenerales,
      ventesParBoutique,
      performancesAgents,
      topProduits,
      evolutionVentes,
      stocksCritiques
    });
  } catch (error) {
    next(error);
  }
};

exports.exporterVentesCSV = async (req, res, next) => {
  try {
    const db = getDatabase();
    const { date_debut, date_fin } = req.query;

    let query = `
      SELECT 
        v.vente_id,
        v.date_vente,
        b.nom_boutique,
        a.prenom_agent || ' ' || a.nom_agent as vendeur,
        p.code_produit,
        p.nom_produit,
        v.qte_vendue,
        p.prix_unitaire,
        v.montant_total
      FROM VENTE v
      INNER JOIN BOUTIQUE b ON v.boutique_id = b.boutique_id
      INNER JOIN AGENT_VENDEUR a ON v.agent_id = a.agent_id
      INNER JOIN PRODUIT p ON v.produit_id = p.produit_id
    `;

    const params = [];
    if (date_debut && date_fin) {
      query += ' WHERE date(v.date_vente) BETWEEN date(?) AND date(?)';
      params.push(date_debut, date_fin);
    }

    query += ' ORDER BY v.date_vente DESC';

    const ventes = await new Promise((resolve, reject) => {
      db.all(query, params, (err, rows) => err ? reject(err) : resolve(rows));
    });

    // Générer le CSV
    let csv = 'ID,Date,Boutique,Vendeur,Code Produit,Produit,Quantité,Prix Unitaire,Montant Total\n';
    
    ventes.forEach(vente => {
      csv += `${vente.vente_id},"${vente.date_vente}","${vente.nom_boutique}","${vente.vendeur}","${vente.code_produit}","${vente.nom_produit}",${vente.qte_vendue},${vente.prix_unitaire},${vente.montant_total}\n`;
    });

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename=ventes.csv');
    res.send(csv);
  } catch (error) {
    next(error);
  }
};