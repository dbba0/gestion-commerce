// ============================================
// FICHIER: src/controllers/produitController.js
// ============================================

const Produit = require('../models/produit');
const Categorie = require('../models/categorie');
const { validationResult } = require('express-validator');

exports.listProduits = async (req, res, next) => {
  try {
    const produits = await Produit.getAll();
    res.render('produits/list', {
      title: 'Gestion des Produits',
      produits,
      success: req.query.success
    });
  } catch (error) {
    next(error);
  }
};

exports.showFormCreate = async (req, res, next) => {
  try {
    const categories = await Categorie.getAll();
    res.render('produits/form', {
      title: 'Nouveau Produit',
      produit: {},
      categories,
      action: '/produits/create'
    });
  } catch (error) {
    next(error);
  }
};

exports.showFormEdit = async (req, res, next) => {
  try {
    const [produit, categories] = await Promise.all([
      Produit.getById(req.params.id),
      Categorie.getAll()
    ]);
    
    if (!produit) {
      return res.status(404).render('error', { 
        message: 'Produit non trouvé',
        error: { status: 404 }
      });
    }

    res.render('produits/form', {
      title: 'Modifier Produit',
      produit,
      categories,
      action: `/produits/update/${produit.produit_id}`
    });
  } catch (error) {
    next(error);
  }
};

exports.createProduit = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const categories = await Categorie.getAll();
      return res.status(400).render('produits/form', {
        title: 'Nouveau Produit',
        produit: req.body,
        categories,
        action: '/produits/create',
        errors: errors.array()
      });
    }

    await Produit.create(req.body);
    res.redirect('/produits?success=created');
  } catch (error) {
    next(error);
  }
};

exports.updateProduit = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const categories = await Categorie.getAll();
      return res.status(400).render('produits/form', {
        title: 'Modifier Produit',
        produit: { produit_id: req.params.id, ...req.body },
        categories,
        action: `/produits/update/${req.params.id}`,
        errors: errors.array()
      });
    }

    await Produit.update(req.params.id, req.body);
    res.redirect('/produits?success=updated');
  } catch (error) {
    next(error);
  }
};

exports.deleteProduit = async (req, res, next) => {
  try {
    await Produit.delete(req.params.id);
    res.redirect('/produits?success=deleted');
  } catch (error) {
    if (error.message.includes('FOREIGN KEY')) {
      return res.status(409).render('error', {
        message: 'Impossible de supprimer ce produit car il est utilisé dans des ventes',
        error: { status: 409 }
      });
    }
    next(error);
  }
};

// API endpoints
exports.getAllProduitsAPI = async (req, res, next) => {
  try {
    const produits = await Produit.getAll();
    res.json({ success: true, data: produits });
  } catch (error) {
    next(error);
  }
};

