
// ============================================
// FICHIER: src/controllers/agentController.js
// ============================================

const Agent = require('../models/agent');
const Boutique = require('../models/boutique');
const { validationResult } = require('express-validator');

exports.listAgents = async (req, res, next) => {
  try {
    const agents = await Agent.getAll();
    res.render('agents/list', {
      title: 'Gestion des Agents Vendeurs',
      agents,
      success: req.query.success
    });
  } catch (error) {
    next(error);
  }
};

exports.showFormCreate = async (req, res, next) => {
  try {
    const boutiques = await Boutique.getAll();
    res.render('agents/form', {
      title: 'Nouvel Agent Vendeur',
      agent: {},
      boutiques,
      action: '/agents/create'
    });
  } catch (error) {
    next(error);
  }
};

exports.showFormEdit = async (req, res, next) => {
  try {
    const [agent, boutiques] = await Promise.all([
      Agent.getById(req.params.id),
      Boutique.getAll()
    ]);
    
    if (!agent) {
      return res.status(404).render('error', { 
        message: 'Agent non trouvé',
        error: { status: 404 }
      });
    }

    res.render('agents/form', {
      title: 'Modifier Agent Vendeur',
      agent,
      boutiques,
      action: `/agents/update/${agent.agent_id}`
    });
  } catch (error) {
    next(error);
  }
};

exports.createAgent = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const boutiques = await Boutique.getAll();
      return res.status(400).render('agents/form', {
        title: 'Nouvel Agent Vendeur',
        agent: req.body,
        boutiques,
        action: '/agents/create',
        errors: errors.array()
      });
    }

    const { nom_agent, prenom_agent, boutique_id } = req.body;
    const db = require('../config/database').getDatabase();
    
    await new Promise((resolve, reject) => {
      db.run(
        'INSERT INTO AGENT_VENDEUR (nom_agent, prenom_agent, boutique_id) VALUES (?, ?, ?)',
        [nom_agent, prenom_agent, boutique_id],
        function(err) {
          if (err) reject(err);
          else resolve({ agent_id: this.lastID });
        }
      );
    });

    res.redirect('/agents?success=created');
  } catch (error) {
    next(error);
  }
};

exports.updateAgent = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const boutiques = await Boutique.getAll();
      return res.status(400).render('agents/form', {
        title: 'Modifier Agent Vendeur',
        agent: { agent_id: req.params.id, ...req.body },
        boutiques,
        action: `/agents/update/${req.params.id}`,
        errors: errors.array()
      });
    }

    const { nom_agent, prenom_agent, boutique_id } = req.body;
    const db = require('../config/database').getDatabase();
    
    await new Promise((resolve, reject) => {
      db.run(
        'UPDATE AGENT_VENDEUR SET nom_agent = ?, prenom_agent = ?, boutique_id = ? WHERE agent_id = ?',
        [nom_agent, prenom_agent, boutique_id, req.params.id],
        function(err) {
          if (err) reject(err);
          else if (this.changes === 0) reject(new Error('Agent non trouvé'));
          else resolve({ updated: true });
        }
      );
    });

    res.redirect('/agents?success=updated');
  } catch (error) {
    next(error);
  }
};

exports.deleteAgent = async (req, res, next) => {
  try {
    const db = require('../config/database').getDatabase();
    
    await new Promise((resolve, reject) => {
      db.run('DELETE FROM AGENT_VENDEUR WHERE agent_id = ?', [req.params.id], function(err) {
        if (err) reject(err);
        else if (this.changes === 0) reject(new Error('Agent non trouvé'));
        else resolve({ deleted: true });
      });
    });

    res.redirect('/agents?success=deleted');
  } catch (error) {
    next(error);
  }
};

