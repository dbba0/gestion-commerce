// ============================================
// FICHIER: src/utils/helpers.js
// ============================================

module.exports = {
  // Formater une date
  formatDate: function(date) {
    if (!date) return '';
    const d = new Date(date);
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const year = d.getFullYear();
    return `${day}/${month}/${year}`;
  },

  // Formater une date et heure
  formatDateTime: function(datetime) {
    if (!datetime) return '';
    const d = new Date(datetime);
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const year = d.getFullYear();
    const hours = String(d.getHours()).padStart(2, '0');
    const minutes = String(d.getMinutes()).padStart(2, '0');
    return `${day}/${month}/${year} ${hours}:${minutes}`;
  },

  // Formater un montant
  formatMoney: function(amount) {
    if (amount === null || amount === undefined) return '0.00 $';
    return Number(amount).toFixed(2) + ' $';
  },

  // Comparaisons
  eq: (a, b) => a == b,
  gt: (a, b) => a > b,
  lt: (a, b) => a < b,
  gte: (a, b) => a >= b,
  lte: (a, b) => a <= b,

  // OR
  or: function() {
    return Array.prototype.slice.call(arguments, 0, -1).some(Boolean);
  },

  // AND
  and: function() {
    return Array.prototype.slice.call(arguments, 0, -1).every(Boolean);
  },

  // Condition avancée
  ifCond: function(v1, operator, v2, options) {
    switch (operator) {
      case '==': return (v1 == v2) ? options.fn(this) : options.inverse(this);
      case '===': return (v1 === v2) ? options.fn(this) : options.inverse(this);
      case '!=': return (v1 != v2) ? options.fn(this) : options.inverse(this);
      case '!==': return (v1 !== v2) ? options.fn(this) : options.inverse(this);
      case '<': return (v1 < v2) ? options.fn(this) : options.inverse(this);
      case '<=': return (v1 <= v2) ? options.fn(this) : options.inverse(this);
      case '>': return (v1 > v2) ? options.fn(this) : options.inverse(this);
      case '>=': return (v1 >= v2) ? options.fn(this) : options.inverse(this);
      default: return options.inverse(this);
    }
  },

  // Incrémenter
  inc: value => parseInt(value) + 1,

  // Multiplier
  multiply: (a, b) => a * b,

  // Classes CSS de stock
  stockClass: function(quantite) {
    if (quantite === 0) return 'stock-zero';
    if (quantite < 5) return 'stock-critical';
    if (quantite < 10) return 'stock-warning';
    return 'stock-ok';
  },

  // Badge de stock
  stockBadge: function(quantite) {
    if (quantite === 0) return '<span class="badge badge-danger">Rupture</span>';
    if (quantite < 5) return '<span class="badge badge-danger">Critique</span>';
    if (quantite < 10) return '<span class="badge badge-warning">Faible</span>';
    return '<span class="badge badge-success">OK</span>';
  },

  // Option <select>
  selected: (value, currentValue) => value == currentValue ? 'selected' : '',

  // Messages succès
  successMessage: function(type) {
    const messages = {
      created: 'Élément créé avec succès',
      updated: 'Élément mis à jour avec succès',
      deleted: 'Élément supprimé avec succès',
      added: 'Stock ajouté avec succès'
    };
    return messages[type] || 'Opération effectuée avec succès';
  },

  // Icônes
  actionIcon: function(action) {
    const icons = {
      edit: 'pencil',
      delete: 'trash',
      view: 'eye',
      add: 'plus',
      save: 'check',
      cancel: 'times'
    };
    return icons[action] || 'cog';
  },

  // Tronquer
  truncate: function(str, length) {
    if (!str || str.length <= length) return str;
    return str.substring(0, length) + '...';
  },

  // Somme
  sum: function(items, field) {
    if (!items || !Array.isArray(items)) return 0;
    return items.reduce((sum, item) => sum + (parseFloat(item[field]) || 0), 0);
  },

  // Debug JSON
  json: context => JSON.stringify(context, null, 2),

  // Helper "unless" personnalisé (si besoin)
  "unless": function(conditional, options) {
    if (!conditional) {
      return options.fn(this);
    }
    return options.inverse(this);
  }
};
