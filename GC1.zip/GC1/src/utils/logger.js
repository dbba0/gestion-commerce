// ============================================
// FICHIER: src/utils/logger.js
// ============================================

class Logger {
    log(level, data) {
      const timestamp = new Date().toISOString();
      const logEntry = {
        timestamp,
        level,
        ...data
      };
      
      console.log(`[${timestamp}] ${level.toUpperCase()}:`, JSON.stringify(data, null, 2));
    }
  
    info(data) {
      this.log('info', data);
    }
  
    error(data) {
      this.log('error', data);
    }
  
    warn(data) {
      this.log('warn', data);
    }
  
    debug(data) {
      if (process.env.NODE_ENV === 'development') {
        this.log('debug', data);
      }
    }
  }
  
  module.exports = new Logger();