// ============================================
// FICHIER: src/routes/agents.js
// ============================================

const express = require('express');
const router = express.Router();
const agentController = require('../controllers/agentController');
const { body } = require('express-validator');

const validateAgent = [
  body('nom_agent')
    .trim()
    .notEmpty()
    .withMessage('Le nom est requis')
    .isLength({ min: 2, max: 50 })
    .withMessage('Le nom doit contenir entre 2 et 50 caractères'),
  
  body('prenom_agent')
    .trim()
    .notEmpty()
    .withMessage('Le prénom est requis')
    .isLength({ min: 2, max: 50 })
    .withMessage('Le prénom doit contenir entre 2 et 50 caractères'),
  
  body('boutique_id')
    .notEmpty()
    .withMessage('La boutique est requise')
    .isInt({ min: 1 })
    .withMessage('Boutique invalide')
];

// Routes pour les vues
router.get('/', agentController.listAgents);
router.get('/new', agentController.showFormCreate);
router.get('/edit/:id', agentController.showFormEdit);
router.post('/create', validateAgent, agentController.createAgent);
router.post('/update/:id', validateAgent, agentController.updateAgent);
router.post('/delete/:id', agentController.deleteAgent);

module.exports = router;