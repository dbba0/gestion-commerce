// ============================================
// FICHIER: src/routes/api.js 
// Routes API pour les mises à jour temps réel
// ============================================

const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middlewares/auth');
const { getDatabase } = require('../config/database');

// API pour les stats du dashboard
router.get('/dashboard/stats', requireAuth, async (req, res, next) => {
  try {
    const db = getDatabase();
    const today = new Date().toISOString().split('T')[0];
    
    const ventesJour = await new Promise((resolve, reject) => {
      db.get(
        `SELECT 
          COUNT(*) as total, 
          SUM(qte_vendue) as quantite,
          SUM(montant_total) as recettes
         FROM VENTE 
         WHERE date(date_vente) = date(?)`,
        [today],
        (err, row) => err ? reject(err) : resolve(row)
      );
    });

    const alertesStock = await new Promise((resolve, reject) => {
      db.all(
        `SELECT p.nom_produit, b.nom_boutique, a.quantite_stock 
         FROM APPROVIONNEMENT a
         INNER JOIN PRODUIT p ON a.produit_id = p.produit_id
         INNER JOIN BOUTIQUE b ON a.boutique_id = b.boutique_id
         WHERE a.quantite_stock < 10
         ORDER BY a.quantite_stock ASC
         LIMIT 10`,
        [],
        (err, rows) => err ? reject(err) : resolve(rows)
      );
    });

    res.json({
      success: true,
      data: {
        ventesJour,
        alertesStock
      }
    });
  } catch (error) {
    next(error);
  }
});

// API pour les ventes récentes
router.get('/ventes/recent', requireAuth, async (req, res, next) => {
  try {
    const Vente = require('../models/vente');
    const ventes = await Vente.getAll(20);
    res.json({ success: true, data: ventes });
  } catch (error) {
    next(error);
  }
});

module.exports = router;