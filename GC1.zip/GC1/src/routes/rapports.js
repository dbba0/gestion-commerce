// ============================================
// FICHIER: src/routes/rapports.js
// ============================================

const express = require('express');
const router = express.Router();
const rapportController = require('../controllers/rapportController');

// Routes pour les rapports
router.get('/', rapportController.showRapports);
router.get('/export/ventes', rapportController.exporterVentesCSV);

module.exports = router;

