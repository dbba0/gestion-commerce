// ============================================
// FICHIER: src/routes/stocks.js
// ============================================

const express = require('express');
const router = express.Router();
const stockController = require('../controllers/stockController');
const { validateStock } = require('../middlewares/validator');

// Routes pour les vues
router.get('/', stockController.listStocks);
router.get('/new', stockController.showFormAdd);
router.post('/add', validateStock, stockController.addStock);

// Routes API
router.get('/api/check', stockController.getStockAPI);

module.exports = router;