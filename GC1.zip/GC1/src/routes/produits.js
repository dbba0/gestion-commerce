// ============================================
// FICHIER: src/routes/produits.js
// ============================================

const express = require('express');
const router = express.Router();
const produitController = require('../controllers/produitController');
const { validateProduit } = require('../middlewares/validator');

// Routes pour les vues
router.get('/', produitController.listProduits);
router.get('/new', produitController.showFormCreate);
router.get('/edit/:id', produitController.showFormEdit);
router.post('/create', validateProduit, produitController.createProduit);
router.post('/update/:id', validateProduit, produitController.updateProduit);
router.post('/delete/:id', produitController.deleteProduit);

// Routes API
router.get('/api/all', produitController.getAllProduitsAPI);

module.exports = router;
