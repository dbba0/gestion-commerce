// ============================================
// FICHIER: src/routes/superviseurs.js
// ============================================

const express = require('express');
const router = express.Router();
const superviseurController = require('../controllers/superviseurController');
const { body } = require('express-validator');

const validateSuperviseur = [
  body('nom_superviss')
    .trim()
    .notEmpty()
    .withMessage('Le nom est requis')
    .isLength({ min: 2, max: 50 })
    .withMessage('Le nom doit contenir entre 2 et 50 caractères'),
  
  body('prenom_supervis')
    .trim()
    .notEmpty()
    .withMessage('Le prénom est requis')
    .isLength({ min: 2, max: 50 })
    .withMessage('Le prénom doit contenir entre 2 et 50 caractères')
];

const validateAffectation = [
  body('boutique_id')
    .notEmpty()
    .withMessage('La boutique est requise')
    .isInt({ min: 1 })
    .withMessage('Boutique invalide'),
  
  body('debut_supervis')
    .notEmpty()
    .withMessage('La date de début est requise')
    .isDate()
    .withMessage('Date invalide')
];

// Routes pour les vues
router.get('/', superviseurController.listSuperviseurs);
router.get('/new', superviseurController.showFormCreate);
router.get('/edit/:id', superviseurController.showFormEdit);
router.get('/:id/boutiques', superviseurController.viewBoutiques);
router.get('/:id/affecter', superviseurController.showFormAffectation);  // ⭐ NOUVEAU
router.post('/create', validateSuperviseur, superviseurController.createSuperviseur);
router.post('/update/:id', validateSuperviseur, superviseurController.updateSuperviseur);
router.post('/delete/:id', superviseurController.deleteSuperviseur);
router.post('/:id/affecter', validateAffectation, superviseurController.affecterBoutique);  // ⭐ NOUVEAU
router.post('/supervision/:id/terminer', superviseurController.terminerSupervision);  // ⭐ NOUVEAU

module.exports = router;