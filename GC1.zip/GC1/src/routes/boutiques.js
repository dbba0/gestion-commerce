// ============================================
// FICHIER: src/routes/boutiques.js
// ============================================

const express = require('express');
const router = express.Router();
const boutiqueController = require('../controllers/boutiqueController');
const { validateBoutique } = require('../middlewares/validator');

// Routes pour les vues
router.get('/', boutiqueController.listBoutiques);
router.get('/new', boutiqueController.showFormCreate);
router.get('/edit/:id', boutiqueController.showFormEdit);
router.post('/create', validateBoutique, boutiqueController.createBoutique);
router.post('/update/:id', validateBoutique, boutiqueController.updateBoutique);
router.post('/delete/:id', boutiqueController.deleteBoutique);

// Routes API
router.get('/api/all', boutiqueController.getAllBoutiquesAPI);
router.get('/api/:id', boutiqueController.getBoutiqueAPI);
router.post('/api/create', validateBoutique, boutiqueController.createBoutiqueAPI);

module.exports = router;
