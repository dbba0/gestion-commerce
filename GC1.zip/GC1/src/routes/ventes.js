// ============================================
// FICHIER: src/routes/ventes.js
// ============================================

const express = require('express');
const router = express.Router();
const venteController = require('../controllers/venteController');
const { validateVente } = require('../middlewares/validator');

// Routes pour les vues
router.get('/', venteController.listVentes);
router.get('/new', venteController.showFormCreate);
router.post('/create', validateVente, venteController.createVente);

// Routes API
router.get('/api/agents/:boutiqueId', venteController.getAgentsByBoutiqueAPI);

module.exports = router;