// ============================================
// FICHIER: src/routes/auth.js 
// ============================================

const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { body } = require('express-validator');

// Validation pour la connexion
const validateLogin = [
  body('username')
    .trim()
    .notEmpty()
    .withMessage('Le nom d\'utilisateur est requis'),
  
  body('password')
    .notEmpty()
    .withMessage('Le mot de passe est requis')
];

// Validation pour l'inscription
const validateRegister = [
  body('username')
    .trim()
    .notEmpty()
    .withMessage('Le nom d\'utilisateur est requis')
    .isLength({ min: 3, max: 50 })
    .withMessage('Le nom d\'utilisateur doit contenir entre 3 et 50 caractères')
    .matches(/^[a-zA-Z0-9_]+$/)
    .withMessage('Le nom d\'utilisateur ne peut contenir que des lettres, chiffres et underscores'),
  
  body('email')
    .trim()
    .notEmpty()
    .withMessage('L\'email est requis')
    .isEmail()
    .withMessage('Email invalide')
    .normalizeEmail(),
  
  body('password')
    .notEmpty()
    .withMessage('Le mot de passe est requis')
    .isLength({ min: 6 })
    .withMessage('Le mot de passe doit contenir au moins 6 caractères'),
  
  body('password_confirm')
    .custom((value, { req }) => value === req.body.password)
    .withMessage('Les mots de passe ne correspondent pas'),
  
  body('role')
    .optional()
    .isIn(['admin', 'superviseur', 'agent'])
    .withMessage('Rôle invalide')
];

// Routes
router.get('/login', authController.showLoginForm);
router.get('/register', authController.showRegisterForm);
router.post('/login', validateLogin, authController.login);
router.post('/register', validateRegister, authController.register);
router.get('/logout', authController.logout);
router.post('/logout', authController.logout);

// API
router.get('/api/check', authController.checkAuth);

module.exports = router;