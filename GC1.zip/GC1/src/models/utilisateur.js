// ============================================
// FICHIER: src/models/utilisateur.js (MISE À JOUR)
// ============================================

const { getDatabase } = require('../config/database');
const bcrypt = require('bcrypt');

class Utilisateur {
  static async hashPassword(password) {
    return await bcrypt.hash(password, 10);
  }

  static async comparePassword(password, hash) {
    return await bcrypt.compare(password, hash);
  }

  static getAll() {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.all('SELECT utilisateur_id, user_name, user_email, user_role, created_at FROM UTILISATEUR ORDER BY user_name', [], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }

  static getById(id) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.get('SELECT utilisateur_id, user_name, user_email, user_role, created_at FROM UTILISATEUR WHERE utilisateur_id = ?', [id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  }

  static getByUsername(username) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.get('SELECT * FROM UTILISATEUR WHERE user_name = ?', [username], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  }

  static getByEmail(email) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.get('SELECT * FROM UTILISATEUR WHERE user_email = ?', [email], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  }

  static async create(data) {
    const { user_name, user_password, user_email, user_role } = data;
    const hashedPassword = await this.hashPassword(user_password);
    
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.run(
        'INSERT INTO UTILISATEUR (user_name, user_password, user_email, user_role) VALUES (?, ?, ?, ?)',
        [user_name, hashedPassword, user_email, user_role || 'agent'],
        function(err) {
          if (err) reject(err);
          else resolve({ 
            utilisateur_id: this.lastID, 
            user_name, 
            user_email, 
            user_role: user_role || 'agent' 
          });
        }
      );
    });
  }

  static async authenticate(username, password) {
    const user = await this.getByUsername(username);
    if (!user) return null;
    
    const isValid = await this.comparePassword(password, user.user_password);
    if (!isValid) return null;
    
    // Retourner l'utilisateur sans le mot de passe
    const { user_password, ...userWithoutPassword } = user;
    return userWithoutPassword;
  }

  static update(id, data) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      const { user_name, user_email, user_role } = data;
      db.run(
        'UPDATE UTILISATEUR SET user_name = ?, user_email = ?, user_role = ? WHERE utilisateur_id = ?',
        [user_name, user_email, user_role, id],
        function(err) {
          if (err) reject(err);
          else if (this.changes === 0) reject(new Error('Utilisateur non trouvé'));
          else resolve({ utilisateur_id: id, ...data });
        }
      );
    });
  }

  static async updatePassword(id, newPassword) {
    const hashedPassword = await this.hashPassword(newPassword);
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.run(
        'UPDATE UTILISATEUR SET user_password = ? WHERE utilisateur_id = ?',
        [hashedPassword, id],
        function(err) {
          if (err) reject(err);
          else if (this.changes === 0) reject(new Error('Utilisateur non trouvé'));
          else resolve({ updated: true });
        }
      );
    });
  }

  static delete(id) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.run('DELETE FROM UTILISATEUR WHERE utilisateur_id = ?', [id], function(err) {
        if (err) reject(err);
        else if (this.changes === 0) reject(new Error('Utilisateur non trouvé'));
        else resolve({ deleted: true });
      });
    });
  }
}

module.exports = Utilisateur;

