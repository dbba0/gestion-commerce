// ============================================
// FICHIER: src/models/vente.js
// ============================================

const { getDatabase } = require('../config/database');

class Vente {
  static getAll(limit = 50) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.all(
        `SELECT v.*, p.nom_produit, p.code_produit, b.nom_boutique, 
                a.nom_agent, a.prenom_agent
         FROM VENTE v
         INNER JOIN PRODUIT p ON v.produit_id = p.produit_id
         INNER JOIN BOUTIQUE b ON v.boutique_id = b.boutique_id
         INNER JOIN AGENT_VENDEUR a ON v.agent_id = a.agent_id
         ORDER BY v.date_vente DESC
         LIMIT ?`,
        [limit],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });
  }

  static getById(id) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.get(
        `SELECT v.*, p.nom_produit, p.prix_unitaire, b.nom_boutique, 
                a.nom_agent, a.prenom_agent
         FROM VENTE v
         INNER JOIN PRODUIT p ON v.produit_id = p.produit_id
         INNER JOIN BOUTIQUE b ON v.boutique_id = b.boutique_id
         INNER JOIN AGENT_VENDEUR a ON v.agent_id = a.agent_id
         WHERE v.vente_id = ?`,
        [id],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });
  }

  static create(data) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      const { produit_id, boutique_id, agent_id, qte_vendue, montant_total, date_vente } = data;

      db.run(
        `INSERT INTO VENTE (produit_id, boutique_id, agent_id, qte_vendue, montant_total, date_vente) 
         VALUES (?, ?, ?, ?, ?, ?)`,
        [produit_id, boutique_id, agent_id, qte_vendue, montant_total, date_vente || new Date().toISOString()],
        function(err) {
          if (err) reject(err);
          else resolve({ vente_id: this.lastID, ...data });
        }
      );
    });
  }
}

module.exports = Vente;