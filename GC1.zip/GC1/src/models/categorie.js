// ============================================
// FICHIER: src/models/categorie.js
// ============================================

const { getDatabase } = require('../config/database');

class Categorie {
  static getAll() {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.all('SELECT * FROM CATEGORIE ORDER BY nom_categorie', [], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }

  static getById(id) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.get('SELECT * FROM CATEGORIE WHERE categorie_id = ?', [id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  }
}

module.exports = Categorie;
