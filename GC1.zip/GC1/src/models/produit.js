// ============================================
// FICHIER: src/models/produit.js
// ============================================

const { getDatabase } = require('../config/database');

class Produit {
  static getAll() {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.all(
        `SELECT p.*, c.nom_categorie 
         FROM PRODUIT p 
         LEFT JOIN CATEGORIE c ON p.categorie_id = c.categorie_id
         ORDER BY p.nom_produit`,
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });
  }

  static getById(id) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.get(
        `SELECT p.*, c.nom_categorie 
         FROM PRODUIT p 
         LEFT JOIN CATEGORIE c ON p.categorie_id = c.categorie_id
         WHERE p.produit_id = ?`,
        [id],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });
  }

  static create(data) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      const { nom_produit, code_produit, prix_unitaire, categorie_id } = data;
      db.run(
        'INSERT INTO PRODUIT (nom_produit, code_produit, prix_unitaire, categorie_id) VALUES (?, ?, ?, ?)',
        [nom_produit, code_produit, prix_unitaire, categorie_id],
        function(err) {
          if (err) reject(err);
          else resolve({ produit_id: this.lastID, ...data });
        }
      );
    });
  }

  static update(id, data) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      const { nom_produit, code_produit, prix_unitaire, categorie_id } = data;
      db.run(
        'UPDATE PRODUIT SET nom_produit = ?, code_produit = ?, prix_unitaire = ?, categorie_id = ? WHERE produit_id = ?',
        [nom_produit, code_produit, prix_unitaire, categorie_id, id],
        function(err) {
          if (err) reject(err);
          else if (this.changes === 0) reject(new Error('Produit non trouvé'));
          else resolve({ produit_id: id, ...data });
        }
      );
    });
  }

  static delete(id) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.run('DELETE FROM PRODUIT WHERE produit_id = ?', [id], function(err) {
        if (err) reject(err);
        else if (this.changes === 0) reject(new Error('Produit non trouvé'));
        else resolve({ deleted: true });
      });
    });
  }
}

module.exports = Produit;
