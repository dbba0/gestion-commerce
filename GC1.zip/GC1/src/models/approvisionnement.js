// ============================================
// FICHIER: src/models/approvisionnement.js
// ============================================

const { getDatabase } = require('../config/database');

class Approvisionnement {
  static getAll() {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.all(
        `SELECT a.*, p.nom_produit, p.code_produit, b.nom_boutique 
         FROM APPROVIONNEMENT a
         INNER JOIN PRODUIT p ON a.produit_id = p.produit_id
         INNER JOIN BOUTIQUE b ON a.boutique_id = b.boutique_id
         ORDER BY a.date_stock DESC`,
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });
  }

  static getByBoutique(boutiqueId) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.all(
        `SELECT a.*, p.nom_produit, p.code_produit 
         FROM APPROVIONNEMENT a
         INNER JOIN PRODUIT p ON a.produit_id = p.produit_id
         WHERE a.boutique_id = ?
         ORDER BY p.nom_produit`,
        [boutiqueId],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });
  }

  static getStock(produitId, boutiqueId) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.get(
        'SELECT quantite_stock FROM APPROVIONNEMENT WHERE produit_id = ? AND boutique_id = ?',
        [produitId, boutiqueId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row ? row.quantite_stock : 0);
        }
      );
    });
  }

  static addStock(data) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      const { produit_id, boutique_id, quantite, date_stock } = data;

      // Vérifier si le stock existe déjà
      db.get(
        'SELECT stock_id, quantite_stock FROM APPROVIONNEMENT WHERE produit_id = ? AND boutique_id = ?',
        [produit_id, boutique_id],
        (err, row) => {
          if (err) {
            reject(err);
            return;
          }

          if (row) {
            // Mettre à jour le stock existant
            const newQte = row.quantite_stock + quantite;
            db.run(
              'UPDATE APPROVIONNEMENT SET quantite_stock = ?, date_stock = ? WHERE stock_id = ?',
              [newQte, date_stock, row.stock_id],
              function(err) {
                if (err) reject(err);
                else resolve({ stock_id: row.stock_id, quantite_stock: newQte });
              }
            );
          } else {
            // Créer un nouveau stock
            db.run(
              'INSERT INTO APPROVIONNEMENT (produit_id, boutique_id, quantite_stock, date_stock) VALUES (?, ?, ?, ?)',
              [produit_id, boutique_id, quantite, date_stock],
              function(err) {
                if (err) reject(err);
                else resolve({ stock_id: this.lastID, quantite_stock: quantite });
              }
            );
          }
        }
      );
    });
  }

  static updateStock(produitId, boutiqueId, quantite) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.run(
        'UPDATE APPROVIONNEMENT SET quantite_stock = quantite_stock + ? WHERE produit_id = ? AND boutique_id = ?',
        [quantite, produitId, boutiqueId],
        function(err) {
          if (err) reject(err);
          else if (this.changes === 0) reject(new Error('Stock non trouvé'));
          else resolve({ updated: true });
        }
      );
    });
  }
}

module.exports = Approvisionnement;