// ============================================
// FICHIER: src/models/agent.js
// ============================================

const { getDatabase } = require('../config/database');

class Agent {
  static getAll() {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.all(
        `SELECT a.*, b.nom_boutique 
         FROM AGENT_VENDEUR a 
         LEFT JOIN BOUTIQUE b ON a.boutique_id = b.boutique_id
         ORDER BY a.nom_agent, a.prenom_agent`,
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });
  }

  static getByBoutique(boutiqueId) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.all(
        'SELECT * FROM AGENT_VENDEUR WHERE boutique_id = ? ORDER BY nom_agent, prenom_agent',
        [boutiqueId],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });
  }

  static getById(id) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.get('SELECT * FROM AGENT_VENDEUR WHERE agent_id = ?', [id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  }
}

module.exports = Agent;