// ============================================
// FICHIER: src/models/superviseur.js
// ============================================

const { getDatabase } = require('../config/database');

class Superviseur {
  static getAll() {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.all(
        'SELECT * FROM SUPERVISEUR ORDER BY nom_superviss, prenom_supervis',
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });
  }

  static getById(id) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.get('SELECT * FROM SUPERVISEUR WHERE supervis_id = ?', [id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  }

  static create(data) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      const { nom_superviss, prenom_supervis } = data;
      db.run(
        'INSERT INTO SUPERVISEUR (nom_superviss, prenom_supervis) VALUES (?, ?)',
        [nom_superviss, prenom_supervis],
        function(err) {
          if (err) reject(err);
          else resolve({ supervis_id: this.lastID, ...data });
        }
      );
    });
  }

  static update(id, data) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      const { nom_superviss, prenom_supervis } = data;
      db.run(
        'UPDATE SUPERVISEUR SET nom_superviss = ?, prenom_supervis = ? WHERE supervis_id = ?',
        [nom_superviss, prenom_supervis, id],
        function(err) {
          if (err) reject(err);
          else if (this.changes === 0) reject(new Error('Superviseur non trouvé'));
          else resolve({ supervis_id: id, ...data });
        }
      );
    });
  }

  static delete(id) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.run('DELETE FROM SUPERVISEUR WHERE supervis_id = ?', [id], function(err) {
        if (err) reject(err);
        else if (this.changes === 0) reject(new Error('Superviseur non trouvé'));
        else resolve({ deleted: true });
      });
    });
  }

  // Obtenir les boutiques supervisées
  static getBoutiquesSupervisees(supervisId) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.all(
        `SELECT s.*, b.nom_boutique, b.tel_boutique, b.adresse_boutique
         FROM SUPERVISER s
         INNER JOIN BOUTIQUE b ON s.boutique_id = b.boutique_id
         WHERE s.supervis_id = ?
         ORDER BY s.debut_supervis DESC`,
        [supervisId],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });
  }

  // Assigner un superviseur à une boutique
  static assignerBoutique(supervisId, boutiqueId, dateDebut, dateFin = null) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.run(
        'INSERT INTO SUPERVISER (supervis_id, boutique_id, debut_supervis, fin_supervis) VALUES (?, ?, ?, ?)',
        [supervisId, boutiqueId, dateDebut, dateFin],
        function(err) {
          if (err) reject(err);
          else resolve({ superviser_id: this.lastID });
        }
      );
    });
  }

  // Terminer la supervision d'une boutique
  static terminerSupervision(superviserId, dateFin) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.run(
        'UPDATE SUPERVISER SET fin_supervis = ? WHERE superviser_id = ?',
        [dateFin, superviserId],
        function(err) {
          if (err) reject(err);
          else if (this.changes === 0) reject(new Error('Supervision non trouvée'));
          else resolve({ updated: true });
        }
      );
    });
  }

  // Obtenir les superviseurs actifs pour une boutique
  static getSuperviseursBoutique(boutiqueId) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.all(
        `SELECT s.*, sup.nom_superviss, sup.prenom_supervis, sv.debut_supervis, sv.fin_supervis
         FROM SUPERVISER sv
         INNER JOIN SUPERVISEUR sup ON sv.supervis_id = sup.supervis_id
         INNER JOIN BOUTIQUE s ON sv.boutique_id = s.boutique_id
         WHERE sv.boutique_id = ? AND (sv.fin_supervis IS NULL OR sv.fin_supervis > date('now'))
         ORDER BY sv.debut_supervis DESC`,
        [boutiqueId],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });
  }
  // Obtenir les boutiques supervisées
static getBoutiquesSupervisees(supervisId) {
  return new Promise((resolve, reject) => {
    const db = getDatabase();
    db.all(
      `SELECT s.superviser_id, s.debut_supervis, s.fin_supervis, 
              b.nom_boutique, b.tel_boutique, b.adresse_boutique
       FROM SUPERVISER s
       INNER JOIN BOUTIQUE b ON s.boutique_id = b.boutique_id
       WHERE s.supervis_id = ?
       ORDER BY s.debut_supervis DESC`,
      [supervisId],
      (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      }
    );
  });
}
}

module.exports = Superviseur;
