// ============================================
// FICHIER: src/models/boutique.js
// ============================================

const { getDatabase } = require('../config/database');

class Boutique {
  static getAll() {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.all('SELECT * FROM BOUTIQUE ORDER BY nom_boutique', [], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }

  static getById(id) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.get('SELECT * FROM BOUTIQUE WHERE boutique_id = ?', [id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  }

  static create(data) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      const { nom_boutique, tel_boutique, adresse_boutique } = data;
      db.run(
        'INSERT INTO BOUTIQUE (nom_boutique, tel_boutique, adresse_boutique) VALUES (?, ?, ?)',
        [nom_boutique, tel_boutique, adresse_boutique],
        function(err) {
          if (err) reject(err);
          else resolve({ boutique_id: this.lastID, ...data });
        }
      );
    });
  }

  static update(id, data) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      const { nom_boutique, tel_boutique, adresse_boutique } = data;
      db.run(
        'UPDATE BOUTIQUE SET nom_boutique = ?, tel_boutique = ?, adresse_boutique = ? WHERE boutique_id = ?',
        [nom_boutique, tel_boutique, adresse_boutique, id],
        function(err) {
          if (err) reject(err);
          else if (this.changes === 0) reject(new Error('Boutique non trouvée'));
          else resolve({ boutique_id: id, ...data });
        }
      );
    });
  }

  static delete(id) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.run('DELETE FROM BOUTIQUE WHERE boutique_id = ?', [id], function(err) {
        if (err) reject(err);
        else if (this.changes === 0) reject(new Error('Boutique non trouvée'));
        else resolve({ deleted: true });
      });
    });
  }
}

module.exports = Boutique;