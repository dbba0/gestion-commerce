// ============================================
// FICHIER: src/models/suivi.js
// ============================================

const { getDatabase } = require('../config/database');

class Suivi {
  static getAll() {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.all(
        `SELECT s.*, u.user_name, a.nom_agent, a.prenom_agent, b.nom_boutique
         FROM SUIVI s
         INNER JOIN UTILISATEUR u ON s.utilisateur_id = u.utilisateur_id
         INNER JOIN AGENT_VENDEUR a ON s.agent_id = a.agent_id
         INNER JOIN BOUTIQUE b ON a.boutique_id = b.boutique_id
         ORDER BY s.debut_suivi DESC`,
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });
  }

  static getById(id) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.get(
        `SELECT s.*, u.user_name, a.nom_agent, a.prenom_agent, b.nom_boutique
         FROM SUIVI s
         INNER JOIN UTILISATEUR u ON s.utilisateur_id = u.utilisateur_id
         INNER JOIN AGENT_VENDEUR a ON s.agent_id = a.agent_id
         INNER JOIN BOUTIQUE b ON a.boutique_id = b.boutique_id
         WHERE s.suivi_id = ?`,
        [id],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });
  }

  static create(data) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      const { utilisateur_id, agent_id, debut_suivi, fin_suivi } = data;
      db.run(
        'INSERT INTO SUIVI (utilisateur_id, agent_id, debut_suivi, fin_suivi) VALUES (?, ?, ?, ?)',
        [utilisateur_id, agent_id, debut_suivi, fin_suivi || null],
        function(err) {
          if (err) reject(err);
          else resolve({ suivi_id: this.lastID, ...data });
        }
      );
    });
  }

  static update(id, data) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      const { debut_suivi, fin_suivi } = data;
      db.run(
        'UPDATE SUIVI SET debut_suivi = ?, fin_suivi = ? WHERE suivi_id = ?',
        [debut_suivi, fin_suivi || null, id],
        function(err) {
          if (err) reject(err);
          else if (this.changes === 0) reject(new Error('Suivi non trouvé'));
          else resolve({ suivi_id: id, ...data });
        }
      );
    });
  }

  static terminerSuivi(id, dateFin) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.run(
        'UPDATE SUIVI SET fin_suivi = ? WHERE suivi_id = ?',
        [dateFin, id],
        function(err) {
          if (err) reject(err);
          else if (this.changes === 0) reject(new Error('Suivi non trouvé'));
          else resolve({ updated: true });
        }
      );
    });
  }

  static delete(id) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.run('DELETE FROM SUIVI WHERE suivi_id = ?', [id], function(err) {
        if (err) reject(err);
        else if (this.changes === 0) reject(new Error('Suivi non trouvé'));
        else resolve({ deleted: true });
      });
    });
  }

  // Obtenir les suivis actifs (non terminés)
  static getSuivisActifs() {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.all(
        `SELECT s.*, u.user_name, a.nom_agent, a.prenom_agent, b.nom_boutique
         FROM SUIVI s
         INNER JOIN UTILISATEUR u ON s.utilisateur_id = u.utilisateur_id
         INNER JOIN AGENT_VENDEUR a ON s.agent_id = a.agent_id
         INNER JOIN BOUTIQUE b ON a.boutique_id = b.boutique_id
         WHERE s.fin_suivi IS NULL OR s.fin_suivi > date('now')
         ORDER BY s.debut_suivi DESC`,
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });
  }

  // Obtenir les suivis par utilisateur
  static getByUtilisateur(utilisateurId) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.all(
        `SELECT s.*, a.nom_agent, a.prenom_agent, b.nom_boutique
         FROM SUIVI s
         INNER JOIN AGENT_VENDEUR a ON s.agent_id = a.agent_id
         INNER JOIN BOUTIQUE b ON a.boutique_id = b.boutique_id
         WHERE s.utilisateur_id = ?
         ORDER BY s.debut_suivi DESC`,
        [utilisateurId],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });
  }

  // Obtenir les suivis par agent
  static getByAgent(agentId) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.all(
        `SELECT s.*, u.user_name, u.user_email
         FROM SUIVI s
         INNER JOIN UTILISATEUR u ON s.utilisateur_id = u.utilisateur_id
         WHERE s.agent_id = ?
         ORDER BY s.debut_suivi DESC`,
        [agentId],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });
  }

  // Obtenir les performances d'un agent sur une période de suivi
  static getPerformancesAgent(suiviId) {
    return new Promise((resolve, reject) => {
      const db = getDatabase();
      db.get(
        `SELECT 
           s.suivi_id,
           s.debut_suivi,
           s.fin_suivi,
           a.nom_agent,
           a.prenom_agent,
           COUNT(v.vente_id) as nombre_ventes,
           SUM(v.qte_vendue) as quantite_totale,
           SUM(v.montant_total) as montant_total,
           AVG(v.montant_total) as montant_moyen
         FROM SUIVI s
         INNER JOIN AGENT_VENDEUR a ON s.agent_id = a.agent_id
         LEFT JOIN VENTE v ON v.agent_id = a.agent_id 
           AND date(v.date_vente) BETWEEN date(s.debut_suivi) 
           AND COALESCE(date(s.fin_suivi), date('now'))
         WHERE s.suivi_id = ?
         GROUP BY s.suivi_id`,
        [suiviId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });
  }
}

module.exports = Suivi;