// ============================================
// FICHIER: src/public/js/realtime.js 
// ============================================

// Connexion Socket.IO
const socket = io();

// Gestion de la connexion
socket.on('connect', () => {
  console.log('✅ Connecté au serveur WebSocket');
});

socket.on('disconnect', () => {
  console.log('❌ Déconnecté du serveur WebSocket');
});

// Écouter les notifications
socket.on('notification', (data) => {
  showNotification(data.message, data.type);
  
  // Émettre un son si disponible
  playNotificationSound();
});

// Écouter les nouvelles ventes
socket.on('nouvelle_vente', (vente) => {
  console.log('💰 Nouvelle vente:', vente);
  
  // Afficher une notification
  showNotification(
    `Nouvelle vente: ${vente.produit} x${vente.quantite} = ${formatCurrency(vente.montant)}`,
    'success'
  );
  
  // Mettre à jour le dashboard si on y est
  if (window.location.pathname === '/dashboard') {
    updateDashboardStats();
  }
  
  // Mettre à jour la liste des ventes si on y est
  if (window.location.pathname === '/ventes') {
    refreshVentesList();
  }
});

// Écouter les alertes de stock
socket.on('alerte_stock', (data) => {
  console.log('⚠️ Alerte stock:', data);
  
  showNotification(
    `Alerte stock: ${data.produit} à la boutique ${data.boutique} (Stock: ${data.quantite})`,
    'warning'
  );
  
  // Mettre à jour le dashboard
  if (window.location.pathname === '/dashboard') {
    updateDashboardStats();
  }
});

// Mise à jour temps réel du dashboard
socket.on('update_dashboard', (data) => {
  console.log('📊 Mise à jour dashboard:', data);
  updateDashboardData(data);
});

// Fonction pour mettre à jour les statistiques du dashboard
async function updateDashboardStats() {
  try {
    const response = await fetch('/api/dashboard/stats');
    const data = await response.json();
    
    if (data.success) {
      updateDashboardData(data.data);
    }
  } catch (error) {
    console.error('Erreur mise à jour dashboard:', error);
  }
}

// Fonction pour mettre à jour les données du dashboard
function updateDashboardData(data) {
  // Mettre à jour les ventes du jour
  const ventesJourTotal = document.querySelector('.stat-value-ventes-total');
  const ventesJourQte = document.querySelector('.stat-value-ventes-qte');
  
  if (ventesJourTotal && data.ventesJour) {
    ventesJourTotal.textContent = data.ventesJour.total || 0;
    animateNumber(ventesJourTotal);
  }
  
  if (ventesJourQte && data.ventesJour) {
    ventesJourQte.textContent = data.ventesJour.quantite || 0;
    animateNumber(ventesJourQte);
  }
  
  // Mettre à jour les alertes de stock (si la section existe)
  const alertesContainer = document.querySelector('.alertes-stock-container');
  if (alertesContainer && data.alertesStock) {
    refreshAlertesStock(data.alertesStock);
  }
}

// Rafraîchir la liste des alertes de stock
function refreshAlertesStock(alertes) {
  const container = document.querySelector('.alertes-stock-container tbody');
  if (!container) return;
  
  if (alertes.length === 0) {
    container.innerHTML = '<tr><td colspan="4" class="empty-message">✅ Aucune alerte de stock</td></tr>';
    return;
  }
  
  container.innerHTML = alertes.map((alerte, index) => `
    <tr class="${getStockClass(alerte.quantite_stock)}">
      <td>${alerte.nom_produit}</td>
      <td>${alerte.nom_boutique}</td>
      <td>${alerte.quantite_stock}</td>
      <td>${getStockBadge(alerte.quantite_stock)}</td>
    </tr>
  `).join('');
}

// Animation des nombres
function animateNumber(element) {
  element.style.transform = 'scale(1.2)';
  element.style.color = 'var(--success-color)';
  
  setTimeout(() => {
    element.style.transform = 'scale(1)';
    element.style.color = '';
  }, 300);
}

// Rafraîchir la liste des ventes
async function refreshVentesList() {
  try {
    const response = await fetch('/api/ventes/recent');
    const data = await response.json();
    
    if (data.success) {
      updateVentesList(data.data);
    }
  } catch (error) {
    console.error('Erreur rafraîchissement ventes:', error);
  }
}

// Afficher une notification
function showNotification(message, type = 'info') {
  const container = document.querySelector('main .container');
  if (!container) return;
  
  const alert = document.createElement('div');
  alert.className = `alert alert-${type} notification-toast`;
  alert.style.cssText = `
    position: fixed;
    top: 80px;
    right: 20px;
    z-index: 9999;
    min-width: 300px;
    animation: slideInRight 0.3s ease-out;
  `;
  
  alert.innerHTML = `
    <span class="alert-icon">${getIconForType(type)}</span>
    <span class="alert-message">${message}</span>
    <button class="alert-close" onclick="this.parentElement.remove()">×</button>
  `;
  
  document.body.appendChild(alert);
  
  // Auto-remove après 5 secondes
  setTimeout(() => {
    alert.style.animation = 'slideOutRight 0.3s ease-out';
    setTimeout(() => alert.remove(), 300);
  }, 5000);
}

// Jouer un son de notification
function playNotificationSound() {
  try {
    const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBTGH0fPTgjMGHm7A7+OZVA==');
    audio.volume = 0.3;
    audio.play().catch(() => {}); // Ignorer les erreurs si le son ne peut pas être joué
  } catch (error) {
    // Ignorer silencieusement
  }
}

// Helper functions
function getIconForType(type) {
  const icons = {
    success: '✓',
    danger: '⚠',
    warning: '⚠',
    info: 'ℹ'
  };
  return icons[type] || 'ℹ';
}

function formatCurrency(amount) {
  return new Intl.NumberFormat('fr-CA', {
    style: 'currency',
    currency: 'CAD'
  }).format(amount);
}

function getStockClass(quantite) {
  if (quantite === 0) return 'stock-zero';
  if (quantite < 5) return 'stock-critical';
  if (quantite < 10) return 'stock-warning';
  return 'stock-ok';
}

function getStockBadge(quantite) {
  if (quantite === 0) return '<span class="badge badge-danger">Rupture</span>';
  if (quantite < 5) return '<span class="badge badge-danger">Critique</span>';
  if (quantite < 10) return '<span class="badge badge-warning">Faible</span>';
  return '<span class="badge badge-success">OK</span>';
}

// CSS pour l'animation
const style = document.createElement('style');
style.textContent = `
@keyframes slideInRight {
  from {
    transform: translateX(100%);
    opacity: 0;
  }
  to {
    transform: translateX(0);
    opacity: 1;
  }
}

@keyframes slideOutRight {
  from {
    transform: translateX(0);
    opacity: 1;
  }
  to {
    transform: translateX(100%);
    opacity: 0;
  }
}

.notification-toast {
  box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}
`;
document.head.appendChild(style);

// Mettre à jour les recettes
const ventesJourRecettes = document.querySelector('.stat-value-ventes-recettes');

if (ventesJourRecettes && data.ventesJour) {
  // Formater en dollars canadiens
  const recettes = parseFloat(data.ventesJour.recettes || 0);
  ventesJourRecettes.textContent = recettes.toFixed(2) + ' $';
  animateNumber(ventesJourRecettes);
}