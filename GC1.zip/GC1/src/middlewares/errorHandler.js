// ============================================
// FICHIER: src/middlewares/errorHandler.js
// ============================================

const logger = require('../utils/logger');

function errorHandler(err, req, res, next) {
  // Logger l'erreur
  logger.error({
    message: err.message,
    stack: err.stack,
    url: req.url,
    method: req.method,
    ip: req.ip,
    timestamp: new Date().toISOString()
  });

  // Déterminer le code d'état
  let statusCode = err.statusCode || 500;
  let message = err.message || 'Erreur interne du serveur';

  // Gérer les erreurs spécifiques de base de données
  if (err.message && err.message.includes('SQLITE_CONSTRAINT')) {
    if (err.message.includes('UNIQUE')) {
      statusCode = 409;
      message = 'Cette valeur existe déjà dans la base de données';
    } else if (err.message.includes('FOREIGN KEY')) {
      statusCode = 409;
      message = 'Impossible d\'effectuer cette opération (contrainte de clé étrangère)';
    }
  }

  // Si c'est une requête API (JSON)
  if (req.xhr || req.headers.accept?.indexOf('json') > -1) {
    return res.status(statusCode).json({
      success: false,
      message: message,
      ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
    });
  }

  // Si c'est une requête web normale (HTML)
  res.status(statusCode).render('error', {
    title: 'Erreur',
    message: message,
    error: process.env.NODE_ENV === 'development' ? err : { status: statusCode }
  });
}

module.exports = errorHandler;
