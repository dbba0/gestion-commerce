// ============================================
// FICHIER: src/middlewares/auth.js 
// ============================================

// Vérifier si l'utilisateur est authentifié
exports.requireAuth = (req, res, next) => {
    if (!req.session || !req.session.userId) {
      if (req.xhr || req.headers.accept?.indexOf('json') > -1) {
        return res.status(401).json({ 
          success: false, 
          message: 'Authentification requise' 
        });
      }
      return res.redirect('/auth/login?error=auth_required');
    }
    next();
  };
  
  // Vérifier le rôle de l'utilisateur
  exports.requireRole = (...roles) => {
    return (req, res, next) => {
      if (!req.session || !req.session.userId) {
        return res.redirect('/auth/login?error=auth_required');
      }
      
      if (!roles.includes(req.session.userRole)) {
        if (req.xhr || req.headers.accept?.indexOf('json') > -1) {
          return res.status(403).json({ 
            success: false, 
            message: 'Accès non autorisé' 
          });
        }
        return res.status(403).render('error', {
          title: 'Accès Interdit',
          message: 'Vous n\'avez pas les permissions nécessaires',
          error: { status: 403 }
        });
      }
      next();
    };
  };
  
  // Middleware pour attacher l'utilisateur à req
  exports.attachUser = async (req, res, next) => {
    if (req.session && req.session.userId) {
      try {
        const Utilisateur = require('../models/utilisateur');
        const user = await Utilisateur.getById(req.session.userId);
        req.user = user;
        res.locals.user = user; // Disponible dans les vues
      } catch (error) {
        console.error('Erreur attachUser:', error);
      }
    }
    res.locals.isAuthenticated = !!req.session?.userId;
    next();
  };
  