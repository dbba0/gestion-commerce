// ============================================
// FICHIER: src/middlewares/validator.js
// ============================================

const { body } = require('express-validator');

exports.validateBoutique = [
  body('nom_boutique')
    .trim()
    .notEmpty()
    .withMessage('Le nom de la boutique est requis')
    .isLength({ min: 3, max: 100 })
    .withMessage('Le nom doit contenir entre 3 et 100 caractères'),
  
  body('tel_boutique')
    .trim()
    .notEmpty()
    .withMessage('Le téléphone est requis')
    .matches(/^[0-9\s\-\+\(\)]{8,20}$/)
    .withMessage('Format de téléphone invalide'),
  
  body('adresse_boutique')
    .trim()
    .notEmpty()
    .withMessage('L\'adresse est requise')
    .isLength({ min: 5, max: 200 })
    .withMessage('L\'adresse doit contenir entre 5 et 200 caractères')
];

exports.validateProduit = [
  body('nom_produit')
    .trim()
    .notEmpty()
    .withMessage('Le nom du produit est requis')
    .isLength({ min: 2, max: 100 })
    .withMessage('Le nom doit contenir entre 2 et 100 caractères'),
  
  body('code_produit')
    .trim()
    .notEmpty()
    .withMessage('Le code produit est requis')
    .matches(/^[A-Z0-9]{3,20}$/)
    .withMessage('Le code doit contenir 3-20 caractères alphanumériques en majuscules'),
  
  body('prix_unitaire')
    .notEmpty()
    .withMessage('Le prix est requis')
    .isFloat({ min: 0.01 })
    .withMessage('Le prix doit être supérieur à 0'),
  
  body('categorie_id')
    .notEmpty()
    .withMessage('La catégorie est requise')
    .isInt({ min: 1 })
    .withMessage('Catégorie invalide')
];

exports.validateStock = [
  body('produit_id')
    .notEmpty()
    .withMessage('Le produit est requis')
    .isInt({ min: 1 })
    .withMessage('Produit invalide'),
  
  body('boutique_id')
    .notEmpty()
    .withMessage('La boutique est requise')
    .isInt({ min: 1 })
    .withMessage('Boutique invalide'),
  
  body('quantite')
    .notEmpty()
    .withMessage('La quantité est requise')
    .isInt({ min: 1 })
    .withMessage('La quantité doit être au moins 1')
];

exports.validateVente = [
  body('produit_id')
    .notEmpty()
    .withMessage('Le produit est requis')
    .isInt({ min: 1 })
    .withMessage('Produit invalide'),
  
  body('boutique_id')
    .notEmpty()
    .withMessage('La boutique est requise')
    .isInt({ min: 1 })
    .withMessage('Boutique invalide'),
  
  body('agent_id')
    .notEmpty()
    .withMessage('L\'agent vendeur est requis')
    .isInt({ min: 1 })
    .withMessage('Agent invalide'),
  
  body('qte_vendue')
    .notEmpty()
    .withMessage('La quantité est requise')
    .isInt({ min: 1 })
    .withMessage('La quantité doit être au moins 1')
];
