// ============================================
// FICHIER: src/config/database.js
// ============================================

const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, '../../database.sqlite');

let db = null;

function getDatabase() {
  if (!db) {
    db = new sqlite3.Database(DB_PATH, (err) => {
      if (err) {
        console.error('Erreur connexion à la base de données:', err);
        throw err;
      }
    });
    db.run('PRAGMA foreign_keys = ON');
  }
  return db;
}

function initDatabase() {
  return new Promise((resolve, reject) => {
    const database = getDatabase();

    const schema = `
      -- Table UTILISATEUR
CREATE TABLE IF NOT EXISTS UTILISATEUR (
  utilisateur_id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_name TEXT NOT NULL UNIQUE,
  user_password TEXT NOT NULL,
  user_email TEXT NOT NULL UNIQUE,
  user_role TEXT NOT NULL DEFAULT 'agent' CHECK(user_role IN ('admin', 'superviseur', 'agent')),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

      -- Table BOUTIQUE
      CREATE TABLE IF NOT EXISTS BOUTIQUE (
        boutique_id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom_boutique TEXT NOT NULL,
        tel_boutique TEXT NOT NULL,
        adresse_boutique TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      -- Table AGENT_VENDEUR
      CREATE TABLE IF NOT EXISTS AGENT_VENDEUR (
        agent_id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom_agent TEXT NOT NULL,
        prenom_agent TEXT NOT NULL,
        boutique_id INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (boutique_id) REFERENCES BOUTIQUE(boutique_id) ON DELETE CASCADE
      );

      -- Table SUPERVISEUR
      CREATE TABLE IF NOT EXISTS SUPERVISEUR (
        supervis_id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom_superviss TEXT NOT NULL,
        prenom_supervis TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      -- Table SUPERVISER (relation superviseur-boutique)
      CREATE TABLE IF NOT EXISTS SUPERVISER (
        superviser_id INTEGER PRIMARY KEY AUTOINCREMENT,
        supervis_id INTEGER NOT NULL,
        boutique_id INTEGER NOT NULL,
        debut_supervis DATE NOT NULL,
        fin_supervis DATE,
        FOREIGN KEY (supervis_id) REFERENCES SUPERVISEUR(supervis_id) ON DELETE CASCADE,
        FOREIGN KEY (boutique_id) REFERENCES BOUTIQUE(boutique_id) ON DELETE CASCADE
      );

      -- Table SUIVI (relation utilisateur-agent)
      CREATE TABLE IF NOT EXISTS SUIVI (
        suivi_id INTEGER PRIMARY KEY AUTOINCREMENT,
        utilisateur_id INTEGER NOT NULL,
        agent_id INTEGER NOT NULL,
        debut_suivi DATE NOT NULL,
        fin_suivi DATE,
        FOREIGN KEY (utilisateur_id) REFERENCES UTILISATEUR(utilisateur_id) ON DELETE CASCADE,
        FOREIGN KEY (agent_id) REFERENCES AGENT_VENDEUR(agent_id) ON DELETE CASCADE
      );

      -- Table CATEGORIE
      CREATE TABLE IF NOT EXISTS CATEGORIE (
        categorie_id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom_categorie TEXT NOT NULL UNIQUE,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      -- Table PRODUIT
      CREATE TABLE IF NOT EXISTS PRODUIT (
        produit_id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom_produit TEXT NOT NULL,
        code_produit TEXT NOT NULL UNIQUE,
        prix_unitaire REAL NOT NULL DEFAULT 0,
        categorie_id INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (categorie_id) REFERENCES CATEGORIE(categorie_id) ON DELETE RESTRICT
      );

      -- Table APPROVIONNEMENT (Stock)
      CREATE TABLE IF NOT EXISTS APPROVIONNEMENT (
        stock_id INTEGER PRIMARY KEY AUTOINCREMENT,
        produit_id INTEGER NOT NULL,
        boutique_id INTEGER NOT NULL,
        quantite_stock INTEGER NOT NULL DEFAULT 0,
        date_stock DATE NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (produit_id) REFERENCES PRODUIT(produit_id) ON DELETE CASCADE,
        FOREIGN KEY (boutique_id) REFERENCES BOUTIQUE(boutique_id) ON DELETE CASCADE,
        UNIQUE(produit_id, boutique_id)
      );

      -- Table VENTE
      CREATE TABLE IF NOT EXISTS VENTE (
        vente_id INTEGER PRIMARY KEY AUTOINCREMENT,
        produit_id INTEGER NOT NULL,
        boutique_id INTEGER NOT NULL,
        agent_id INTEGER NOT NULL,
        date_vente DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        qte_vendue INTEGER NOT NULL,
        montant_total REAL NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (produit_id) REFERENCES PRODUIT(produit_id) ON DELETE RESTRICT,
        FOREIGN KEY (boutique_id) REFERENCES BOUTIQUE(boutique_id) ON DELETE RESTRICT,
        FOREIGN KEY (agent_id) REFERENCES AGENT_VENDEUR(agent_id) ON DELETE RESTRICT
      );

      -- Index pour améliorer les performances
      CREATE INDEX IF NOT EXISTS idx_vente_date ON VENTE(date_vente);
      CREATE INDEX IF NOT EXISTS idx_vente_boutique ON VENTE(boutique_id);
      CREATE INDEX IF NOT EXISTS idx_appro_produit ON APPROVIONNEMENT(produit_id);
      CREATE INDEX IF NOT EXISTS idx_appro_boutique ON APPROVIONNEMENT(boutique_id);
    `;

    database.exec(schema, (err) => {
      if (err) {
        console.error('❌ Erreur création des tables:', err);
        reject(err);
      } else {
        console.log('✅ Base de données initialisée avec succès');
        insertSampleData(database)
          .then(() => resolve(database))
          .catch(reject);
      }
    });
  });
}

function insertSampleData(database) {
  return new Promise((resolve, reject) => {
    database.get('SELECT COUNT(*) as count FROM BOUTIQUE', (err, row) => {
      if (err) {
        reject(err);
        return;
      }

      // Si déjà des données, ne pas insérer
      if (row.count > 0) {
        console.log('📦 Données d\'exemple déjà présentes');
        resolve();
        return;
      }

      const sampleData = `
        -- Insertion des catégories
        INSERT INTO CATEGORIE (nom_categorie) VALUES 
          ('Électronique'),
          ('Vêtements'),
          ('Alimentation'),
          ('Meubles'),
          ('Livres');

        -- Insertion des boutiques
        INSERT INTO BOUTIQUE (nom_boutique, tel_boutique, adresse_boutique) VALUES 
          ('Boutique Centre-Ville', '0123456789', '123 Rue Principale, Ottawa'),
          ('Boutique Est', '0123456790', '456 Avenue de l''Est, Ottawa'),
          ('Boutique Ouest', '0123456791', '789 Boulevard de l''Ouest, Ottawa');

        -- Insertion des superviseurs
        INSERT INTO SUPERVISEUR (nom_superviss, prenom_supervis) VALUES 
          ('Dubois', 'Marie'),
          ('Martin', 'Pierre');

        -- Insertion des agents vendeurs
        INSERT INTO AGENT_VENDEUR (nom_agent, prenom_agent, boutique_id) VALUES 
          ('Tremblay', 'Jean', 1),
          ('Gagnon', 'Sophie', 1),
          ('Roy', 'Marc', 2),
          ('Côté', 'Julie', 2),
          ('Bouchard', 'Luc', 3);

        -- Insertion des produits
        INSERT INTO PRODUIT (nom_produit, code_produit, prix_unitaire, categorie_id) VALUES 
          ('Ordinateur Portable', 'ELEC001', 999.99, 1),
          ('Souris Sans Fil', 'ELEC002', 29.99, 1),
          ('Clavier Mécanique', 'ELEC003', 89.99, 1),
          ('T-Shirt Coton', 'VET001', 19.99, 2),
          ('Jean Slim', 'VET002', 49.99, 2),
          ('Pain Complet', 'ALIM001', 3.99, 3),
          ('Lait 1L', 'ALIM002', 2.49, 3),
          ('Bureau en Bois', 'MEUB001', 299.99, 4),
          ('Chaise Ergonomique', 'MEUB002', 199.99, 4),
          ('Roman Policier', 'LIV001', 14.99, 5);

        -- Insertion des approvisionnements (stock)
        INSERT INTO APPROVIONNEMENT (produit_id, boutique_id, quantite_stock, date_stock) VALUES 
          (1, 1, 15, '2025-11-01'),
          (2, 1, 50, '2025-11-01'),
          (3, 1, 30, '2025-11-01'),
          (4, 1, 100, '2025-11-01'),
          (5, 1, 75, '2025-11-01'),
          (1, 2, 10, '2025-11-01'),
          (2, 2, 40, '2025-11-01'),
          (6, 2, 200, '2025-11-01'),
          (7, 2, 150, '2025-11-01'),
          (8, 3, 5, '2025-11-01'),
          (9, 3, 8, '2025-11-01'),
          (10, 3, 45, '2025-11-01');

        -- Insertion de quelques ventes
        INSERT INTO VENTE (produit_id, boutique_id, agent_id, date_vente, qte_vendue, montant_total) VALUES 
          (2, 1, 1, '2025-11-23 09:30:00', 3, 89.97),
          (4, 1, 2, '2025-11-23 10:15:00', 5, 99.95),
          (1, 1, 1, '2025-11-23 11:00:00', 1, 999.99),
          (6, 2, 3, '2025-11-23 08:45:00', 10, 39.90),
          (7, 2, 4, '2025-11-23 09:20:00', 8, 19.92);
      `;

      database.exec(sampleData, (err) => {
        if (err) {
          console.error('❌ Erreur insertion des données d\'exemple:', err);
          reject(err);
        } else {
          console.log('✅ Données d\'exemple insérées avec succès');
          resolve();
        }
      });
    });
  });
}

module.exports = {
  getDatabase,
  initDatabase
};